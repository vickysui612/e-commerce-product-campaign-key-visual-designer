# 实心 Icon ＋实测两角色文字：通用执行

适合卖点Icon表达时，在本次precise-layout.json顶层feature_groups放一个集中模块，结构从assets/feature-module.template.json复制。背景色角色必须引用本次品牌/场景配色并写color_rationale；不采用参考图的固定色值。默认circle实心底，高对比前景优先白色；浅底不适合白线时自动选更高对比黑色，或指定协调前景角色。不能用文字/图标品牌色代替场景色彩协调。

items各含id、semantic_evidence、glyph和copy.zh/en。每个copy含copy_id、title、body，title+body逐字等于当前brief母本（包括空格/标点），不编造说明。glyph是规范化内框0–1坐标的line/polyline（points）、ellipse（box）、arc（box/start/end）数组，不包含固定商品图形；由当前确认功能绘制相应语义图标。所有图形共用线宽、色彩、内边距，以实际图形包围框居中缩放，不能混风格。

每种languages配置position、text_width、title_token、body_token，可选group_gap；布局的coordinate_space可以normalized或pixels。共享token字体从本次fonts.json解析，**整组全部标题/说明分别选择能覆盖所有字的同一个字体**，避免逐条fallback改变风格。H3/Body分别有统一颜色、字重/轴值和行距。

动态计算在scripts/feature_module.py与precise_render.py中完成：
- title_font_size/description_font_size：读取共享token的size_ratio（按画布宽缩放）或有据size_px；未指定时由画布和该语言文本框宽度自动推导共享字号，并实测所有文案，不做单条缩字。
- text_group_height：真实字体各换行行框＋共享leading＋标题说明间距，包含整组实际物理行，非第一行字号。
- icon_container_size：中英全组共同计算一个直径；以实测高度的85%–110%交集为约束，diameter_ratio为偏好。交集为空先调整文本框/布局；合理例外必须ratio_exception_reason并实际视觉验收，不能静默接受小图标或放大单项。
- icon_graphic_size：共享直径和glyph_padding_ratio推导内框，再按真实glyph轮廓等比居中；glyph_stroke_ratio共用。
- icon_text_gap：共享直径×icon_text_gap_ratio，非每项独立坐标。
- feature_group_spacing：未填group_gap时由全组实测slot高度×feature_group_spacing_ratio算出；显式组距也按当前画布的坐标体系读取。
- vertical_alignment：图标和完整文字块中心对齐，默认中英共享row slot及直径，文字独立排版，居中误差/比例留档。

默认实心圆、统一两层语义，特殊容器可用rounded_square且必须style_exception_reason。资料缺少说明时允许有依据手工单层方案，但不得伪称使用两层模块。裸asset.kind=icon手工替代需要manual_feature_module_reason；不能继续默认为固定小图标/细圈。

`precise_render.py --validate-only`可先测量；通过已审核hero后渲染时，会绘制实心底/规范化线性图形及两角色文字，输出feature_modules报告，不自动视觉PASS。新图重置全部视觉子项；前期测量不替代100%模块/双语缩略图检查。

## 已正确场景的局部组件修订

`revise_feature_modules.py --project PROJECT_ROOT --spec working/feature-revision.json`只修已有卖点组件。输入source_root/source_manifest、原来联合hero的clean_hero/hero_receipt、product_protection_mask、当前layout，以及languages各自source/erase_boxes/output。冻结既有成图和干净hero，当前母本/原商品/Logo必须与原件快照相同；保留原生成及身份/空间审核来源。

仅用同一干净hero恢复旧卖点像素，再叠新模块，不调用模型、不重画商品、不补影；保护mask不得与清除/新绘区域交叠。逐通道验证编辑区外像素完全不变，保存mask、来源/结果哈希及component_revision收据。该模式是局部版式修订，不能冒称重新联合生成。脚本同时创建本次work/render-manifest.json（可用--manifest指定不同于来源manifest的新路径），登记新outputs和测量收据，并自动清空旧C版本/哈希/结论及全部视觉子项；父来源manifest保持原样以保留收据哈希。新manifest中原件基线和前期授权按项目记录规则另行核对，不自动搬入旧C。最终仍必须新做Feature Module QA和成图C；原商品/Logo、品牌场景色、字体、母本和双语/尺寸规则继续生效。
