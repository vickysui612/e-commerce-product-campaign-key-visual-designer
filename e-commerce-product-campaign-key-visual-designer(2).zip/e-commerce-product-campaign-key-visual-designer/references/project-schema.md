# 项目记录格式与运行

本 Skill 文件夹与每次海报项目分开。项目根目录中的 `brief.json`、`output/working/render-manifest.json` 由模板创建；原素材放在项目自定路径。所有路径可相对项目根目录，也可为当前机器上的绝对路径；**不要把某台机器的绝对路径写进 Skill 模板**。

```text
python SKILL_ROOT/scripts/preflight.py init --project PROJECT_ROOT
# 填好 brief.json，保留真实素材；开始修改/抠图前做原件快照
python SKILL_ROOT/scripts/preflight.py snapshot --project PROJECT_ROOT
# 两版候选图、排版记录与看图验收完成后
python SKILL_ROOT/scripts/preflight.py check --project PROJECT_ROOT
```

Python 3.10+；合并版保留 Pillow/fontTools 的完整PNG解码、字体加载和字形覆盖检查，依赖见 scripts/requirements.txt。缺 Python 或图像工具时可人工完成对应检查，必须如实记录未自动检查项；不能把脚本未运行写成 PASS。`init` 不覆盖已有文件。`snapshot` 拒绝覆盖已有资产哈希，防止加工后重设基线。

## brief.json 字段

- `sources[]`：`id`、`type`、`locator`，建议另记 `path_or_url`、`provider`、`accessed_at`。定位必须精确到页/段/时间码或网页位置。
- `facts[]`：`id`、`key`（同一事实及适用范围）、`value`（原值含单位/条件）、`claim`、`source_ids[]`、`locator`、`classification=must_show|background|forbidden`、`status=confirmed|superseded`。失效/被裁定不采用的事实可保留为 `superseded`，但须有对应已解决冲突。
- `conflicts[]`：`id`、`key`、候选值及来源、`status=unresolved|resolved`、`resolution_source_id`、裁定原文/理由。脚本会拦截同一 `key` 的不同值而无已解决冲突记录。
- `requirements.mandatory_copy_ids[]`：各语言必须上图的文案 ID；`forbidden_claims[]` 为不能宣称的内容。
- `copy.zh[]` / `copy.en[]`：每项 `id`、`text`、`source_ids[]`、`fact_ids[]`、`status=confirmed|confirmed_translation`。`fact_ids` 将已确认事实映射到上图文案；必上图事实需在每个要求的语言中被映射。换行是版式属性，`text` 保留母本原文。
- `design.directions[]`：2–3 个方向，每项有 ID、策略、构图/商品占比、场景、信息层级、适用原因及风险。填写 `selected_id`、`selection_reason`、每个未采用方案的 `rejected_reasons[]` 和 3–5 句 `brief_rationale`。
- `delivery`：实际宽高、格式、语言与尺寸依据。默认值仅在任务没有规定时使用。

## render-manifest.json 字段

`assets` 是 `snapshot` 自动记录的原件路径与 SHA-256。`outputs` 每种要求的语言各一项 `{language,path}`。`rendered_text.zh/en` 每项 `{id,text}`，由实际排版源导出，与 brief 逐项对比。`fonts_used` 记录每个实际字体的路径、用途、fallback 原因与授权状态；合并版要求实际text_blocks/runs记录字体角色、路径、SHA-256及fallback原因；脚本核查加载/字形覆盖与fonts.json映射，风格仍要看样张。`gates` 三项写 `status=PASS|REVISE|BLOCKED`、`reviewer=executor|human` 与可核验 `evidence`；没有真人参与时用 `executor`。`visual_qa` 按当前模板全部项目同样需 PASS 与具体证据。`iterations` 记录问题、修订指令、候选图版本与复查结果。

新版默认三个人工节点：没有真人答复保持 `PENDING`；只有 `brief.review_policy.waivers` 中有本次有效的真人授权原文，检查器才接受对应 `executor` 放行。默认模板 waivers 为空。每个 gate 建议另存 `object_version`、`review_objects`、`pass_criteria`。不因模板字段齐全就声称实际审核已完成。

`design.visual_strategy` 记录本次商品气质、受众关系、背景、配色、打光、参考原则；模板不预置固定商品或风格。`manifest.layout_audit` 记录 `method=measured|manual`、实际检查证据、可选报告路径。测量报告应来自最终采用的字体、文案和布局；程序只检查报告存在，不能替代查看像素图。

检查器不是海报生成器，也不自动判断来源权威性、中文字体美感或接触阴影是否真实。先按参考附录做视觉判断，再填写真实结论。

## 视觉记录与新审核项

可从assets/layout-system.template.json建立工作样式表，模板仅记录结构、不提供固定海报。token_styles记录字体/字号/字重/字距/颜色/行距，copy_role_map记录母本ID的语义级别。headline_groups记录组ID/行ID、整组或逐行变换、运动方向、角度、字体协调与例外理由；feature_groups记录信息关系、A/B/C内部结构、圆形/线性/徽章/符号体系、尺寸/笔画/内边距、icon+text单元关系及集中竖/横排列；promotion_groups记录母本ID、形式、价格子角色、条件、CTA关系、连续路径与选择理由。compose记录商品锚点、阅读路径、品牌依据及与旧布局比较；全部填本次实际值，不造固定角度或价格。

scene_pipeline记录mode/plan/work；默认unified_hero的prepare→实际原图输入联合生成→ingest→关键细节对照→accept来源与哈希由unified_workflow验证。layered_fallback必须有明确category/evidence，不默认回退。visual_qa包括unified_product_identity、photographic_unity、information_cohesion以及headline_motion与promotion_composition等当前模板项目，均需实际成图版本和具体证据。现有manifest不在Skill维护时批量改写；下次执行补做新检查，不直接继承PASS。字体、商品、Logo、尺寸、双语和Grounding Pass门槛继续适用。

参数化摄影与语言布局、原件局部恢复和隔离跨商品命令见 [参数化执行](portable-execution.md)。scene-plan.photography记录本次商品bounds/重心、相机高度、景深与主/环境光；字体、颜色、位置、卖点IDs、修复四边形均来自项目配置，不属于Skill常量。新版本receipt同时冻结brief与实际prompt，旧receipt不能直接当作新版本生成证据；不改写历史文件，下一次制作重新prepare并审核。

## C文件绑定与旧schema2兼容

新模板标记 `review_binding_revision=c-output-sha256-v1`，保持schema_version=2及A/B/C。C新增 `reviewed_outputs:[{language,sha256}]`，每个交付语言恰好一项，SHA-256来自真正展示的最终PNG；检查器重新读取文件字节比对。该规则不依赖标记是否存在，删标记不能绕过。缺项、重复语言、错误哈希或文件变化均FAIL，并给迁移提示。

Skill更新不改写任何历史brief/manifest或已批准海报。旧schema2在原版本下的验收作为历史保留；下一次用新检查器执行前备份记录，展示当前候选并记录新C绑定。只有既有证据能确证用户看过且批准的正是同一字节版本时才可复用；不能计算今天文件的哈希并自动把历史PASS当作新批准。A/B授权仍按原范围有效性判断。

新渲染/局部修订自动重置C和全部视觉子项，保留旧证据到iterations；不会自动批准。局部修订默认写入本次work/render-manifest.json，可用--manifest指定新目标，禁止覆盖作为来源的parent manifest。新manifest没有原件基线时应按已核对的当前原件执行snapshot（已有基线不可覆盖），按实际证据补A/B等其余记录，不从旧图自动移植C。

## 合并版保留项与旧数据迁移

init还创建 assets/fonts/zh、en 与缺失的assets/fonts.json，不覆盖配置。每次先读映射，再用 `preflight.py scan-fonts --project PROJECT_ROOT` 扫描本地.ttf/.otf；layout_probe的系统清单只是可用性辅助，不越过本地字体优先规则。

manifest增加 `text_blocks.zh/en`：每个ID含`runs`，每run含`text/font_role/font_path/font_sha256/fallback_reason`（可另记字号、轴值）。拼接等于rendered_text与brief原文。`visual_qa`增加独立`contact_grounding`和`typography`；必须有实际图像证据。

默认严格4:5、中英各一张PNG。偏离时在brief.exam_override保存被覆盖的width/height/languages/format、有效source_id及evidence；不能仅改delivery值绕过规格。confirmed_translation另在translation_authorization记录对应语言用户授权/确认原文。

当前schema1记录保留，check会明确提示迁移而不会偷偷按旧规范放行。下一次制作前：备份brief.json及原manifest；以schema2模板为目标逐项迁移，完整保留原字段与母本；sources补真实ID/type/locator，facts分类及copy.fact_ids按原始资料核对，不能仅从模糊旧摘要编造出处；旧assets哈希原样迁入，严禁重拍基线。rendered_text从旧实际runs拼接而非母本反填；text_blocks原样保留。设计方向、layout_audit和A/B/C仅填真实可追溯证据，缺项保持待补；历史视觉PASS不直接迁移，尤其已经被用户指出失败的落地项。完成后以新版check验收。迁移是下一次执行的资料准备，不在仅更新Skill时改写当前商品配置。
