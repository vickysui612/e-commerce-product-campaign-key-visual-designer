# 旧记录兼容与本版工作流

当前默认数据结构为 schema_version 2，执行以 [项目记录格式](project-schema.md) 为准。原schema1模板仍在 assets/legacy/，原确定性函数保存在 scripts/preflight_legacy.py 供历史脚本/自测兼容；它不是新版最终放行入口。

每次统一调用 scripts/preflight.py。发现旧schema1时 `check` 明确阻止最终放行；先按 project-schema.md 迁移记录，保留母本、字体配置和原件哈希，不重置资产基线或编造新来源/人工签字。迁移资料中的待补项在正式执行时由实际资料补齐。

场景仍先以真实商品定锚点，记录画布、轮廓、比例、主体轴线、底部接触区、承载面、光源、保护遮罩与文字安全区，生成承载骨架并叠图验证后才丰富背景。随后完成 [独立落地融合](grounding.md)。本版信息设计依 [字体规范](typography.md) 与 [真实文字测量](typography-layout.md)，源run拼接仍须逐字等于母本。
