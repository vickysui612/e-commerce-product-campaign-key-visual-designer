# 参数化执行：Skill 本体与案例分离

`SKILL_ROOT` 是本 SKILL.md 所在目录，`PROJECT_ROOT` 是本次资料目录。全部通用执行代码来自 `SKILL_ROOT/scripts/`；项目只提供原件、brief、字体映射、摄影计划、语言版式和验收记录。不得 import 历史案例的 Python，不得把测试工作目录写成默认输入。课程默认尺寸仍保留；实际程序尺寸来自 brief.delivery，不是商品坐标常量。

## 计划、实际模型调用与审核

palette按 [Brand Color Strategy / Color System / Scene Planning](product-style.md) 填写完整roles（primary/secondary/accent/neutral/background_tone）、六类analysis和brand_color_source；来源method为logo_sampled、official_standard或not_adopted。采用品牌色时，scene_applications条目必须含target/palette_role/treatment/relationship，且至少一个target属于实际环境而非仅Icon/文字/价格。旧字符串应用条目需按本次分析迁移，不能仅复制历史名称或PASS。最终color_harmony保留六项有证据的子检查，结构见 [Color QA](qa.md)。

1. 填 `brief.json`、`assets/fonts.json` 和本次 `scene-plan.json`。摄影字段 `photography` 包含 product_bounds、visual_center、camera_height、depth_of_field、key_light、ambient_light；与 camera、support.anchor/perspective_rationale、materials、palette、props、一个 feature_groups 共同进入生成提示词。围绕商品选择承载方式、景深、主/环境光及道具；不能复用旧商品坐标而不重新分析。
2. `python SKILL_ROOT/scripts/unified_workflow.py prepare --project PROJECT_ROOT --plan working/scene-plan.json`。输出 `generation-inputs.json` 的 prompt/referenced_image_paths 是实际工具调用输入，原商品必须排第一。读取任务时绑定本次原件、Logo、画布与卖点 IDs；冻结 brief、原件和计划。品牌候选支持位图与 SVG 原始填充/描边声明，SVG 候选不是面积统计，也不替代官方规范。
3. 由执行者实际调用可用图像生成/编辑工具，不能把 prepare 的提示词当成成图；工具能力/真实保真不足时按有据备选执行。保存实际 prompt、输入顺序、tool/tool_call_evidence 与 method=product_referenced_joint_generation，再 ingest。实际提示词也纳入哈希，之后改文案/计划/输出/提示词须重新准备和审核。
4. 使用 `inspect_images.py --project PROJECT_ROOT --spec working/inspection.json` 创建原件/候选并排和底部、Logo、透明材质局部。**实际打开**，自行观察后填写 review，再 accept。程序只输出 NOT_CHECKED，不会把自然落地、视觉统一或保真自动标 PASS。

## 局部原件细节恢复

`restore_details.py --project PROJECT_ROOT --spec working/detail-repair.json --out working/hero-repaired.png` 仅在必要时恢复原件局部印字/标识/面板；不是商品整体贴图器。字段：source、hero、region、reason、source_quad 和 target_quad（各4个本图像素点）、原图 product_bounds。可选轻微 illumination_factors、局部 edge_feather_px；无固定商品、暖光因子或坐标。

必须以当前原图为 source，另存结果，不覆盖原件/候选；局部映射保留原标识与文字像素，不能伪造整体三维视角。区域包围框不超过所声明商品包围框的25%是保守的软件防误用门槛，**不是正确修复的视觉证明**；区域/轮廓仍须人工核实。输出 mask、来源/结果哈希、变换和 NOT_CHECKED 记录。整台结构失真应重生成，不能用一大块原商品替换。原件低清字体不会被臆造为高清。

## 中英文精确渲染

从 `assets/precise-layout.template.json` 建语言布局。`precise_render.py --project PROJECT_ROOT --layout working/precise-layout.json --validate-only` 在制作前验证真实字体/字形、文案及文本框；验证不生成海报。

hero 通过实际审核后去掉 `--validate-only` 渲染。该脚本直接使用审核后的完整联合图，只加原 Logo、文字和图标/图形；禁止回贴整张原商品，禁止另补任意阴影。原件快照及 scene_pipeline 仍由 preflight/unified 流程维护。新图通过review_binding统一把全部视觉子项重置NOT_CHECKED，C重置PENDING并清空旧版本、对象与哈希，旧证据归档到iterations。最终PNG先导出再展示，按[人工审核](human-review.md)绑定真实答复与展示时的逐语言SHA-256；外部导出入口需显式invalidate，最终preflight也会核对当前文件字节。

布局字段：hero、scene_pipeline、coordinate_space=normalized|pixels、colors、languages、report。
- 每种 languages 包含 output、styles、text_blocks、assets。每个母本文案 ID 恰好一个 text_block，含 copy_id、runs；全部 runs.text 拼接必须等于该母本。单 run 可省 text 表示读母本全文。
- 每个 run 由 token、position（2坐标）、可选 width 控制位置/自动换行，绝不独立缩小同组字号。styles[token] 包含 font_role、size_ratio（相对画布宽）或 size_px、color_role，可选 leading/variation_axes。角色共用规范由本次语义分级决定，中英文各自适配，不从商品价格推测内容。
- assets 只为 logo/icon/graphic，含 kind、path、position、size；等比 fit，禁止旋转/变色/拉伸。独立 Logo path 必须等于 brief 中的原文件。crop 仅允许原件背景留白，人工检查不能裁伤 Logo。SVG 忠实栅格化可用可选 CairoSVG；缺运行库明确报错，不能重画。
- 先读取 fonts.json 并扫描本地 zh/en。优先 primary → 配置 fallback → 已显式启用系统兜底；缺字或加载失败不得静默忽略。有本地字体却选外部系统字体时须写 local_font_decision。输出字体/字形/run/几何报告，不宣称字体美感自动合格。

Icon卖点使用顶层feature_groups（复制assets/feature-module.template.json中的组结构），由 [通用模块](feature-module.md) 实测双语高度和统一图标；feature copy不再重复填普通text_blocks。已正确的商品/背景只改组件时用revise_feature_modules，冻结既有海报/干净hero与来源审核并验证区域外/商品像素不变，不能伪称新联合生成。修订同时写本次work/render-manifest.json，可用--manifest指定新目标；不会修改父来源manifest，也不会自动继承其C。后续snapshot/check须通过--manifest指向这个新记录，原件基线及前期授权按project-schema核对。

留白、构图、品牌场景色、语义图标、动态标题和价格强度仍是当前商品的设计判断；JSON 是判断结果，不是固定海报模板。换商品重新建立摄影/版式参数即可，无需改 Python 中的商品坐标。

## 跨商品调用检查

`check_portability.py --cases cases.json --out portability-report.json` 接收任意两个以上 `{project,plan,layout,label}` 记录。它把 Skill 和最少原件/资料复制到隔离临时目录，真实调用通用 prepare 和双语 validate-only，变更卖点组数量与另一4:5分辨率，仅检查输入/代码可迁移。它不复制旧海报、旧场景或案例 Python，也不调用模型，报告 visual_status=NOT_TESTED。生成图片自然度须另行跨商品视觉测试；当前用户仅请求更新时不得继续做海报。
