# 默认联合生成与有据分层备选

## 默认 Product-Anchored Unified Hero Generation

填写assets/scene-plan.template.json，render_mode=unified_hero。默认以原商品为身份输入，共同规划摄影空间、真实承载/光源/景深、道具层级、品牌场景色和集中信息区域。identity_constraints填写真实解剖结构与关键细节；layout只设一个统一卖点组。不固定任何品牌/价格/版式坐标。

1. `python scripts/unified_workflow.py prepare --project PROJECT --plan working/scene-plan.json`：核对原件/Logo、相机/材质、保真清单和集中信息区，输出色彩候选、生成计划、必须传入的原始reference_inputs与冻结哈希。
2. 实际调用可用图像生成/编辑工具，传入receipt.reference_inputs对应的原图。原商品优先身份依据，风格图仅指导自然光影和信息区，不能复制他牌商品、宣称或文案。工具生成完整商品＋场景，不能环境-only再贴商品。记录实际prompt、referenced_image_paths、tool/tool_call_evidence与method=product_referenced_joint_generation。
3. `python scripts/unified_workflow.py ingest --project PROJECT --plan working/scene-plan.json --generated working/joint-hero.png --submission working/generation-submission.json`：登记实际联合输出及调用来源，状态仍NOT_CHECKED。全图等比适配画布，不能单独拉伸商品；变换记录来源。
4. 实际打开原件/候选并排和关键局部，逐项记录轮廓/比例、控制结构、固有色、原印字标识、玻璃反光、接触/重量、透视、光影、商品道具、集中信息区与品牌场景色；失败针对联合图重生成，不把整个原抠图贴回去。必要原件局部标志/面板恢复记录source/region/reason/transform与前后比较，whole_product_reoverlay禁止为true。
5. `python scripts/unified_workflow.py accept --project PROJECT --plan working/scene-plan.json --out working/hero-reviewed.png --review working/hero-review.json`：要求所有REVIEWS的真实PASS和comparison_images，再叠加原Logo和程序化营销文字。最终中英成图仍单独实际看图QA并人工C；不能因为模型输出看着自然而免身份审核。

脚本不本地调用模型、不承诺模型可保真，也不从单张照片精确重建相机、不可见面或光学透射。它生成可执行输入计划并核对真实工具输入/结果/保真审核证据；必须实际用工具完成联合生成。结构错误、乱码或看似同类替身只能REVISE/BLOCKED。

实际计划还须填写photography的商品范围/重心、相机高度、景深、主光/环境光，且与本次brief原件、尺寸和文案IDs绑定。prepare会输出可供真实图像工具调用的generation-inputs.json；读取 [参数化执行](portable-execution.md) 完成通用局部检查/恢复与双语渲染，不调用案例Python。

## 仅例外 layered_fallback

允许原因类别user_original_cutout、information_display、tool_limitation、identity_risk；必须在fallback_reason中写category/evidence，不能自动退回。先以商品主视角规划场景和集中信息区，运行scene_workflow.py prepare→accept-scene→composite。保留原件/遮罩、真实接触轮廓与独立环境阴影，仍检查摄影统一、无贴PNG/悬空。此路径不能冒称联合生成；历史候选不因此自动通过。

preflight分模式校验执行来源，并强制unified_product_identity、photographic_unity、information_cohesion及原有全部QA。软件检查的只是流程/记录/哈希/精确文字，不能证明保真或摄影自然。
