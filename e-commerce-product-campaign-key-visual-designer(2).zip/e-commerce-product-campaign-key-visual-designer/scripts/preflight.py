"""Member-v3 integrated checks: provenance, human gates, protected assets and exact fonts."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
from preflight_legacy import read_json, save_json, digest, font_info, scan, VISUAL_KEYS

SKILL = Path(__file__).resolve().parents[1]
GATES = ('A_requirements', 'B_direction', 'T_layout_promotion', 'C_final')
VISUAL = ('factual_integrity', 'product_logo_integrity', 'bilingual_consistency',
          'typography_layout', 'headline_motion', 'promotion_composition', 'contact_lighting', 'contact_grounding', 'typography', 'cta_readability', 'color_harmony', 'perspective_material', 'prop_hierarchy', 'typeface_fit', 'unified_product_identity', 'photographic_unity', 'information_cohesion')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def locate(root, value):
    if not isinstance(value, str) or not value.strip():
        raise ValueError('missing path')
    return (root / value).resolve()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def png_size(path):
    with Path(path).open('rb') as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b'\x89PNG\r\n\x1a\n' or header[12:16] != b'IHDR':
        raise ValueError('not a valid PNG header')
    return struct.unpack('>II', header[16:24])


def assets(brief):
    product = brief.get('product', {})
    values = [product.get('image'), product.get('logo')]
    values += product.get('visual_assets', [])
    return [v for v in values if v]


def init(root):
    for rel, target in [('assets/brief.template.json', 'brief.json'),
                        ('assets/render-manifest.template.json', 'output/working/render-manifest.json'),
                        ('assets/fonts.json', 'assets/fonts.json')]:
        target_path = root / target
        if not target_path.exists():
            target_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SKILL / rel, target_path)
    for rel in ('assets/fonts/zh', 'assets/fonts/en', 'output/preview', 'output/final'):
        (root / rel).mkdir(parents=True, exist_ok=True)
    return {'status': 'INITIALIZED', 'project': str(root), 'note': 'Fill the brief before final check.'}


def snapshot(root, manifest_file):
    brief = read(root / 'brief.json')
    manifest_path = locate(root, manifest_file)
    data = read(manifest_path) if manifest_path.exists() else read(SKILL / 'assets/render-manifest.template.json')
    if brief.get('schema_version') != 2 or data.get('schema_version') != 2:
        raise ValueError('Legacy records: migrate per references/project-schema.md; never reset an existing asset baseline.')
    if data.get('assets'):
        raise ValueError('Asset baseline already exists; preserve the original snapshot.')
    data['assets'] = [{'path': p, 'sha256': sha(locate(root, p))} for p in assets(brief)]
    write(manifest_path, data)
    return {'status': 'BASELINE_SAVED', 'assets': len(data['assets'])}


def check(root, manifest_file):
    errors, warnings = [], []
    brief = read(root / 'brief.json')
    manifest = read(locate(root, manifest_file))
    if brief.get('schema_version') != 2 or manifest.get('schema_version') != 2:
        report = {'status':'FAIL','errors':['Schema 1 records are preserved. Before the next production, migrate to matching schema 2 per references/project-schema.md, preserving copy/fonts/original hashes and redoing review. Do not use legacy checks as final approval.'], 'warnings':[]}
        write(root / 'output/preflight/check-report.json', report)
        return report
    delivery = brief.get('delivery', {})
    width, height = delivery.get('width'), delivery.get('height')
    if type(width) is not int or type(height) is not int or (type(width) is int and type(height) is int and min(width, height) <= 0):
        errors.append('Delivery width/height must be positive integers.')
    languages = delivery.get('languages', [])
    if not languages or len(set(languages)) != len(languages):
        errors.append('Delivery languages are missing or duplicated.')

    sources = brief.get('sources', [])
    source_ids = [s.get('id') for s in sources]
    if not source_ids or any(not x for x in source_ids) or len(set(source_ids)) != len(source_ids):
        errors.append('Sources need unique nonempty IDs.')
    source_set = set(source_ids)
    for source in sources:
        if not source.get('locator') or not source.get('type'):
            errors.append('Source needs type and precise locator: ' + str(source.get('id')))
    facts = brief.get('facts', [])
    fact_ids = [f.get('id') for f in facts]
    if not facts:
        errors.append('No product facts recorded.')
    if len(set(fact_ids)) != len(fact_ids):
        errors.append('Duplicate fact IDs.')
    fact_set = set(fact_ids)
    resolved_keys = {c.get('key') for c in brief.get('conflicts', [])
                     if c.get('status') == 'resolved' and c.get('resolution_source_id') in source_set}
    by_key = {}
    for fact in facts:
        fid = str(fact.get('id'))
        if not fact.get('id') or not fact.get('key') or not fact.get('value') or not fact.get('claim') or fact.get('classification') not in ('must_show', 'background', 'forbidden'):
            errors.append('Incomplete fact: ' + fid)
        if fact.get('key') and fact.get('value'):
            by_key.setdefault(fact['key'], set()).add(str(fact['value']))
        if fact.get('status') != 'confirmed' and not (fact.get('status') == 'superseded' and fact.get('key') in resolved_keys):
            errors.append('Unconfirmed fact: ' + fid)
        if not fact.get('source_ids') or any(s not in source_set for s in fact.get('source_ids', [])) or not fact.get('locator'):
            errors.append('Fact lacks valid source and locator: ' + fid)
    for conflict in brief.get('conflicts', []):
        if conflict.get('status') != 'resolved' or not conflict.get('resolution_source_id'):
            errors.append('Unresolved source conflict: ' + str(conflict.get('id')))
        elif conflict.get('resolution_source_id') not in source_set:
            errors.append('Conflict resolution has unknown source: ' + str(conflict.get('id')))
    for key, values in by_key.items():
        if len(values) > 1 and key not in resolved_keys:
            errors.append('Conflicting values for fact key without documented resolution: ' + key)

    req = brief.get('requirements', {})
    if not req.get('purpose') or not req.get('audience') or not req.get('goal'):
        errors.append('Purpose, audience and goal are required.')
    mandatory = set(req.get('mandatory_copy_ids', []))
    if not mandatory:
        warnings.append('No mandatory_copy_ids recorded; confirm that this is intentional.')
    product = brief.get('product', {})
    if not product.get('image'):
        errors.append('Original product image is required.')
    if not product.get('logo') and not product.get('logo_not_applicable_reason'):
        errors.append('Original logo or a reason it does not apply is required.')
    baseline = manifest.get('assets', [])
    for path in assets(brief):
        try:
            real = locate(root, path)
            matches = [a for a in baseline if locate(root, a.get('path')) == real]
            if len(matches) != 1 or matches[0].get('sha256') != sha(real):
                errors.append('Asset absent from baseline or modified: ' + path)
        except Exception as exc:
            errors.append('Asset error ' + str(path) + ': ' + str(exc))

    design = brief.get('design', {})
    for key in ('product_character', 'audience_link', 'background', 'palette', 'lighting', 'reference_principles'):
        if not design.get('visual_strategy', {}).get(key):
            errors.append('Record product-specific visual_strategy.' + key)
    directions = design.get('directions', [])
    if not 2 <= len(directions) <= 3 or not design.get('selected_id') or not design.get('selection_reason') or not design.get('brief_rationale'):
        errors.append('Record 2–3 distinct directions, selected ID, selection reason and short design rationale.')
    elif design['selected_id'] not in [d.get('id') for d in directions]:
        errors.append('Selected direction ID is absent.')
    if len(design.get('rejected_reasons', [])) < max(0, len(directions) - 1):
        errors.append('Record why every unselected direction was rejected.')

    rendered = manifest.get('rendered_text', {})
    for language in languages:
        copy = brief.get('copy', {}).get(language, [])
        actual = rendered.get(language, [])
        ids = [c.get('id') for c in copy]
        if not ids or len(set(ids)) != len(ids):
            errors.append(language + ': missing or duplicate copy IDs.')
        if not mandatory.issubset(set(ids)):
            errors.append(language + ': mandatory copy IDs missing.')
        actual_by_id = {a.get('id'): a.get('text') for a in actual}
        if len(actual_by_id) != len(actual) or set(actual_by_id) != set(ids):
            errors.append(language + ': rendered text IDs differ from brief.')
        shown_facts = set()
        for item in copy:
            cid = item.get('id')
            if item.get('status') not in ('confirmed', 'confirmed_translation') or not item.get('text'):
                errors.append(language + ': unconfirmed/empty copy ' + str(cid))
            if not item.get('source_ids') or any(s not in source_set for s in item.get('source_ids', [])):
                errors.append(language + ': copy lacks valid source ' + str(cid))
            fids = item.get('fact_ids', [])
            if any(fid not in fact_set for fid in fids):
                errors.append(language + ': copy links unknown fact ' + str(cid))
            shown_facts.update(fids)
            if actual_by_id.get(cid) != item.get('text'):
                errors.append(language + ': rendered text differs from brief ' + str(cid))
        required_facts = {f.get('id') for f in facts if f.get('classification') == 'must_show' and f.get('status') == 'confirmed'}
        if not required_facts.issubset(shown_facts):
            errors.append(language + ': must_show facts not mapped into copy: ' + ', '.join(sorted(required_facts - shown_facts)))

    outputs = manifest.get('outputs', [])
    if sorted(o.get('language') for o in outputs) != sorted(languages):
        errors.append('Exactly one output per required language is needed.')
    for output in outputs:
        try:
            path = locate(root, output.get('path'))
            if delivery.get('format', '').upper() != 'PNG' or path.suffix.lower() != '.png' or png_size(path) != (width, height):
                errors.append('Wrong output format/dimensions: ' + str(path))
        except Exception as exc:
            errors.append('Output error: ' + str(exc))
    for group, keys in (('gates', GATES), ('visual_qa', VISUAL)):
        for key in keys:
            record = manifest.get(group, {}).get(key, {})
            if record.get('status') != 'PASS' or not str(record.get('evidence', '')).strip():
                errors.append(group + '.' + key + ' has no documented PASS.')
            if group == 'gates' and record.get('reviewer') not in ('executor', 'human'):
                errors.append('Gate reviewer must be executor or human: ' + key)
            if group == 'gates' and record.get('reviewer') != 'human':
                waiver = brief.get('review_policy', {}).get('waivers', {}).get(key, {})
                if waiver.get('authorized_by') != 'human' or not str(waiver.get('evidence', '')).strip():
                    errors.append('Human review or explicit user waiver required: ' + key)
    # Both image-based human decisions must match the actual current file bytes.
    from review_binding import binding_errors
    for key in ('T_layout_promotion', 'C_final'):
        errors.extend(binding_errors(root, manifest, languages, key))
    audit = manifest.get('layout_audit', {})
    if audit.get('method') not in ('measured', 'manual') or not audit.get('evidence'):
        errors.append('Record actual text layout measurements or documented manual inspection.')
    if audit.get('report_path'):
        try:
            if not locate(root, audit['report_path']).is_file():
                raise ValueError('missing report')
        except Exception as exc:
            errors.append('Layout report invalid: ' + str(exc))
        try:
            layout_report=read(locate(root,audit['report_path']))
            if layout_report.get('feature_modules'):
                from feature_module import qa_errors as feature_qa_errors
                errors.extend(feature_qa_errors(manifest.get('visual_qa',{}).get('typography_layout',{})))
        except Exception as exc:
            errors.append('Feature module measurement/review report invalid: '+str(exc))
    for used in manifest.get('fonts_used', []):
        try:
            if not locate(root, used.get('path')).is_file():
                raise ValueError('missing font')
        except Exception as exc:
            errors.append('Font record invalid: ' + str(exc))
    if not manifest.get('fonts_used'):
        errors.append('Record fonts actually used, including any fallback.')

    from scene_workflow import check_record
    errors.extend(check_record(root, manifest.get('scene_pipeline', {})))
    try:
        from color_strategy import qa_errors
        scene_plan=read(locate(root,manifest['scene_pipeline']['plan']))
        errors.extend(qa_errors(manifest.get('visual_qa',{}).get('color_harmony',{}),scene_plan['palette']))
    except Exception as exc:
        errors.append('Brand Color Harmony QA record invalid: '+str(exc))

    try:
        from protection_checks import check as protection_check
        added_errors, added_warnings = protection_check(root, brief, manifest)
        errors.extend(added_errors); warnings.extend(added_warnings)
    except Exception as exc:
        errors.append('Required font/image protection checks could not complete: ' + str(exc))
    report = {'status': 'FAIL' if errors else 'PASS', 'errors': errors, 'warnings': warnings,
              'note': 'Deterministic checks only. Visual PASS must come from opening and inspecting the actual images.'}
    write(root / 'output/preflight/check-report.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('init', 'scan-fonts', 'snapshot', 'check'))
    parser.add_argument('--project', required=True)
    parser.add_argument('--manifest', default='output/working/render-manifest.json')
    args = parser.parse_args()
    root = Path(args.project).resolve()
    try:
        result = (init(root) if args.command == 'init' else scan(root) if args.command == 'scan-fonts' else
                  snapshot(root, args.manifest) if args.command == 'snapshot' else
                  check(root, args.manifest))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1 if result.get('status') == 'FAIL' else 0
    except Exception as exc:
        print(json.dumps({'status': 'ERROR', 'error': str(exc)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    sys.exit(main())
