"""Pre-generation camera/palette plan, explicit scene review, original-pixel compositing.
This is a 2D support/matte helper, not a camera solver, glass renderer or aesthetic judge.
"""
from pathlib import Path
import argparse,json,hashlib,math
import re,collections,xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFilter,ImageChops

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def path(root,v): return (Path(root)/v).resolve()
def colors(file,roi=None):
    if Path(file).suffix.lower()=='.svg':
        # Read original vector colors; never redraw the logo to sample it.
        counts=collections.Counter()
        for node in ET.parse(file).getroot().iter():
            declarations=dict(re.findall(r'([\w-]+)\s*:\s*([^;]+)',node.get('style','')))
            for key in ('fill','stroke'):
                value=node.get(key,declarations.get(key,''))
                if value and value.lower() not in ('none','transparent','currentcolor'):
                    try:
                        from PIL import ImageColor
                        color=ImageColor.getrgb(value)
                        counts['#'+''.join(f'{v:02x}' for v in color[:3])]+=1
                    except ValueError:pass
        return [{'hex':k,'samples':v,'sampling':'SVG paint declarations, not area-weighted'} for k,v in counts.most_common(6)]
    im=Image.open(file).convert('RGBA')
    if roi: im=im.crop(tuple(roi))
    im.thumbnail((256,256));counts={}
    for r,g,b,a in im.getdata():
        if a<200 or min(r,g,b)>238: continue
        key=tuple(round(v/16)*16 for v in (r,g,b));counts[key]=counts.get(key,0)+1
    ranked=sorted(counts.items(),key=lambda x:x[1],reverse=True)[:6]
    return [{'hex':'#'+''.join(f'{min(v,255):02x}' for v in k),'samples':n} for k,n in ranked]
def validate(root,p):
    assert p.get('render_mode')=='layered_fallback', 'Default is unified_hero; use unified_workflow with original reference inputs'
    reason=p.get('fallback_reason') or {}
    assert reason.get('category') in ('user_original_cutout','information_display','tool_limitation','identity_risk') and reason.get('evidence'), 'Explicit justified fallback required'
    for key in ('source','mask','logo'): assert path(root,p[key]).is_file(),f'Missing {key}'
    w,h=p['canvas'];assert min(w,h)>0
    cam=p['camera']
    for k in ('angle','elevation','visible_surfaces','vertical_axis','perspective','base_geometry','lighting_direction','material_properties','evidence','limitations'):
        assert cam.get(k),f'Camera analysis missing {k}'
    assert p['support'].get('perspective_rationale'),'Support must match original camera before generation'
    assert p['palette'].get('roles') and p['palette'].get('rationale'),'Missing scene palette strategy'
    from color_strategy import validate as validate_color
    validate_color(root,p)
    if p['palette'].get('brand_is_design_basis'):
        assert p['palette'].get('scene_applications'),'Brand color cannot be text-only'
    assert p['materials'].get('strategy') and p['materials'].get('limitations'),'Material strategy required'
    assert p['composition'].get('mode') and p['composition'].get('reason'),'Choose layout for this product'
    for prop in p['props']:
        assert prop.get('relation') and prop.get('role') in (2,3,4),'Props need meaning and hierarchy'
        assert not prop.get('unsupported_claim'),'Prop implies unsupported fact'
    tr=p['transform'];assert tr['scale']>0 and len(tr['translation'])==2
    assert not any(tr.get(k) for k in ('perspective_warp','skew','scale_x','scale_y')),'Nonuniform/pseudo-3D transform forbidden'
    assert len(p['contact_contour'])>=2,'Physical base contour required'
    source=Image.open(path(root,p['source']));mask=Image.open(path(root,p['mask']))
    assert source.size==mask.size,'Matte must match original dimensions'
    assert mask.convert('L').getbbox(),'Empty product matte'
    return p

def point(p,xy):
    t=p['transform'];a=math.radians(t.get('rotation_degrees',0));c=math.cos(a)*t['scale'];d=math.sin(a)*t['scale'];x,y=xy
    return (c*x-d*y+t['translation'][0],d*x+c*y+t['translation'][1])
def prepare(root,planfile,work='working/scene-pipeline'):
    p=validate(root,read(path(root,planfile)));folder=path(root,work);folder.mkdir(parents=True,exist_ok=True)
    contour=[point(p,q) for q in p['contact_contour']]
    plane=Image.new('L',tuple(p['canvas']));ImageDraw.Draw(plane).polygon(p['support']['polygon'],fill=255)
    for x,y in contour:
        assert 0<=x<p['canvas'][0] and 0<=y<p['canvas'][1] and plane.getpixel((round(x),round(y)))>0,'Base lies outside support top'
    cp={'logo_candidates':colors(path(root,p['logo']),p.get('logo_color_roi')),'product_candidates':colors(path(root,p['source']),p.get('product_color_roi')),'note':'Photo samples are color candidates, not official brand standards or material identification.'}
    write(folder/'color-analysis.json',cp)
    guide=Image.new('RGB',tuple(p['canvas']),'#edf2f3');draw=ImageDraw.Draw(guide);draw.polygon(p['support']['polygon'],fill='#dfd5c6');draw.line(contour,fill='#c85230',width=4)
    src=Image.open(path(root,p['source'])).convert('RGBA');src.putalpha(Image.open(path(root,p['mask'])).convert('L'));guide.paste(transform(p,src),(0,0),transform(p,src))
    for zone in p.get('text_safe_zones',[]):draw.rectangle(zone,outline='#35617a',width=2)
    guide.save(folder/'anchor-guide.png')
    prompt=('Use case: ads-marketing. Environment only, no products, typography, logos or watermarks.\n'
            +'Canvas: '+str(p['canvas'])+'\nCamera: '+json.dumps(p['camera'],ensure_ascii=False)+'\n'
            +'Product anchor: '+json.dumps({'transform':p['transform'],'contact':contour,'support':p['support']},ensure_ascii=False)+'\n'
            +'Palette: '+json.dumps(p['palette'],ensure_ascii=False)+'\nMaterials: '+json.dumps(p['materials'],ensure_ascii=False)+'\n'
            +'Composition: '+json.dumps(p['composition'],ensure_ascii=False)+'\nProps: '+json.dumps(p['props'],ensure_ascii=False)+'\nText safe zones: '+str(p.get('text_safe_zones',[])))
    (folder/'generation-plan.txt').write_text(prompt,encoding='utf-8')
    receipt={'stage':'PREPARED','plan':planfile,'plan_sha256':sha(path(root,planfile)), 'source_sha256':sha(path(root,p['source'])),'mask_sha256':sha(path(root,p['mask'])),'logo_sha256':sha(path(root,p['logo'])),'colors':str((folder/'color-analysis.json').relative_to(Path(root).resolve())),'visual_status':'NOT_CHECKED'}
    write(folder/'receipt.json',receipt);return receipt

def frozen(root,planfile,work):
    p=validate(root,read(path(root,planfile)));receipt=read(path(root,work)/'receipt.json')
    for key,file in [('plan',planfile),('source',p['source']),('mask',p['mask']),('logo',p['logo'])]: assert receipt[key+'_sha256']==sha(path(root,file)),f'{key} changed; prepare and review again'
    return p,receipt

def accept_scene(root,planfile,scene,review,work='working/scene-pipeline'):
    p,r=frozen(root,planfile,work);q=read(path(root,review))
    for k in ('perspective','support','lighting','palette','material_backdrop','props'):
        item=q.get(k,{});assert item.get('status')=='PASS' and item.get('evidence'),f'Actual scene review missing {k}'
    assert Image.open(path(root,scene)).size==tuple(p['canvas']),'Scene must match planned canvas; re-plan after resizing'
    r.update(stage='SCENE_REVIEWED',scene=scene,scene_sha256=sha(path(root,scene)),review=review,review_sha256=sha(path(root,review)))
    write(path(root,work)/'receipt.json',r);return r

def transform(p,im):
    t=p['transform'];a=math.radians(t.get('rotation_degrees',0));scale=t['scale'];c=math.cos(a)/scale;d=math.sin(a)/scale;tx,ty=t['translation']
    return im.transform(tuple(p['canvas']),Image.Transform.AFFINE,(c,d,-c*tx-d*ty,-d,c,d*tx-c*ty),Image.Resampling.BICUBIC)

def composite(root,planfile,out,work='working/scene-pipeline'):
    p,r=frozen(root,planfile,work);assert r['stage'] in ('SCENE_REVIEWED','COMPOSITED'),'Scene must be opened and reviewed before product placement'
    assert sha(path(root,r['scene']))==r['scene_sha256'] and sha(path(root,r['review']))==r['review_sha256'],'Scene/review changed; review again'
    scene=Image.open(path(root,r['scene'])).convert('RGBA');src=Image.open(path(root,p['source'])).convert('RGBA');src.putalpha(Image.open(path(root,p['mask'])).convert('L'));product=transform(p,src)
    w,h=p['canvas'];plane=Image.new('L',(w,h));ImageDraw.Draw(plane).polygon(p['support']['polygon'],fill=255)
    contour=[point(p,q) for q in p['contact_contour']];shadow=p['shadows'];folder=path(root,work)
    def shadow_layer(mask,color,opacity,name):
        mask=ImageChops.multiply(mask,plane).point(lambda v:round(v*opacity));im=Image.new('RGBA',(w,h),tuple(color)+(0,));im.putalpha(mask);im.save(folder/(name+'.png'));return im
    line=Image.new('L',(w,h));ImageDraw.Draw(line).line(contour,fill=255,width=shadow['contact_width'],joint='curve')
    contact=shadow_layer(line.filter(ImageFilter.GaussianBlur(shadow['contact_blur'])),shadow['color'],shadow['contact_opacity'],'contact')
    ao=shadow_layer(line.filter(ImageFilter.GaussianBlur(shadow['ao_blur'])),shadow['color'],shadow['ao_opacity'],'ao')
    # Project the original silhouette toward the light-derived vector onto the reviewed plane.
    # This is an explicitly approximate 2.5D projection, not a fitted 3D volume.
    vx,vy=shadow['cast_vector'];base_x,base_y=p['support']['anchor'];height=shadow['reference_height']
    kx=vx/height;ky=vy/height;assert abs(ky)>.001,'Cast vector needs nonzero support-plane depth'
    inv=(1,-kx/ky,kx*base_y/ky,0,-1/ky,base_y*(1+ky)/ky)
    castmask=product.getchannel('A').transform((w,h),Image.Transform.AFFINE,inv,Image.Resampling.BICUBIC).filter(ImageFilter.GaussianBlur(shadow['cast_blur']))
    cast=shadow_layer(castmask,shadow['color'],shadow['cast_opacity'],'cast')
    before=scene.copy();before.alpha_composite(product);before.save(folder/'before-contact.png')
    for layer in (cast,ao,contact,product):scene.alpha_composite(layer)
    path(root,out).parent.mkdir(parents=True,exist_ok=True);scene.save(path(root,out));product.save(folder/'protected-product.png');product.getchannel('A').save(folder/'protection-mask.png')
    r.update(stage='COMPOSITED',output=out,output_sha256=sha(path(root,out)),contact_contour=contour,limitations=p['materials']['limitations'],visual_status='NOT_CHECKED')
    write(folder/'receipt.json',r);return r

def check_record(root,record):
    if record.get('mode')=='component_revision':
        from revise_feature_modules import check_record as revision_check
        return revision_check(root,record)
    if record.get('mode')=='unified_hero':
        from unified_workflow import check_record as joint_check
        return joint_check(root,record)
    errors=[]
    try:
        p,r=frozen(root,record['plan'],record['work'])
        assert r['stage']=='COMPOSITED','Actual prepare/review/composite sequence incomplete'
        for key in ('scene','review','output'):assert sha(path(root,r[key]))==r[key+'_sha256'],key+' receipt mismatch'
    except Exception as e:errors.append('scene_pipeline: '+str(e))
    return errors

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('command',choices=['prepare','accept-scene','composite']);a.add_argument('--project',required=True);a.add_argument('--plan',required=True);a.add_argument('--work',default='working/scene-pipeline');a.add_argument('--scene');a.add_argument('--review');a.add_argument('--out');x=a.parse_args();root=Path(x.project).resolve()
    result=(prepare(root,x.plan,x.work) if x.command=='prepare' else accept_scene(root,x.plan,x.scene,x.review,x.work) if x.command=='accept-scene' else composite(root,x.plan,x.out,x.work));print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
