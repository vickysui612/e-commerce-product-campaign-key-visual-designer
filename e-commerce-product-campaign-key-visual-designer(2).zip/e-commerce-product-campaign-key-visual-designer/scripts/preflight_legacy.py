"""Deterministic preflight; visual review remains mandatory. Python 3.10+."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys

SKILL = Path(__file__).resolve().parents[1]
VISUAL_KEYS = ('source_review', 'product_integrity', 'contact_grounding', 'logo_integrity', 'copy_visual',
               'typography', 'typography_layout', 'bilingual_adaptation', 'readability')


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def resolve(root, path):
    if not isinstance(path, str) or not path.strip():
        raise ValueError('Missing file path')
    return (root / path).resolve()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def display_path(root, path):
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return str(path)


def font_info(root, path, text=''):
    from fontTools.ttLib import TTFont
    from PIL import ImageFont
    path = resolve(root, path)
    if path.suffix.lower() not in ('.ttf', '.otf'):
        raise ValueError('Only .ttf and .otf are supported: ' + str(path))
    with TTFont(str(path), lazy=False) as font:
        cmap = font.getBestCmap() or {}
        missing = sorted({c for c in text if not c.isspace() and
                          (ord(c) not in cmap or cmap[ord(c)] == '.notdef')})
        family = font['name'].getDebugName(1) if 'name' in font else None
        style = font['name'].getDebugName(2) if 'name' in font else None
        axes = {a.axisTag: [a.minValue, a.defaultValue, a.maxValue]
                for a in font['fvar'].axes} if 'fvar' in font else {}
        weight = font['OS/2'].usWeightClass if 'OS/2' in font else None
        glyphs = len(cmap)
    loaded = ImageFont.truetype(str(path), 40)
    loaded.getbbox(text or 'Ag 0129')
    return {'path': display_path(root, path), 'sha256': digest(path),
            'family': family, 'style': style, 'weight': weight, 'axes': axes,
            'unicode_glyph_count': glyphs, 'missing_characters': missing,
            'loadable': True}


def init(root):
    for language in ('zh', 'en'):
        (root / 'assets/fonts' / language).mkdir(parents=True, exist_ok=True)
    for src, target in [('assets/fonts.json', 'assets/fonts.json'),
                        ('assets/legacy/brief.template.json', 'brief.json')]:
        if not (root / target).exists():
            save_json(root / target, read_json(SKILL / src))
    return {'status': 'INITIALIZED', 'project': str(root),
            'note': 'Existing configs preserved; blank brief is not final-ready.'}


def scan(root):
    # Read mapping first, as required; never overwrite role assignments.
    mapping = read_json(root / 'assets/fonts.json')
    result = {'fonts': [], 'errors': [], 'configured_roles': list(mapping.get('roles', {}))}
    for language in ('zh', 'en'):
        directory = root / 'assets/fonts' / language
        directory.mkdir(parents=True, exist_ok=True)
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix.lower() in ('.ttf', '.otf'):
                try:
                    record = font_info(root, str(path))
                    record['directory_language'] = language
                    result['fonts'].append(record)
                except Exception as exc:
                    result['errors'].append({'path': display_path(root, path), 'error': str(exc)})
    save_json(root / 'output/preflight/font-inventory.json', result)
    return result


def asset_paths(brief):
    product = brief.get('product', {})
    paths = [product.get('image')]
    if product.get('logo'):
        paths.append(product['logo'])
    return paths


def snapshot(root, destination):
    brief = read_json(root / 'brief.json')
    output = resolve(root, destination)
    if output.exists():
        raise ValueError('Snapshot destination exists; choose a new file to preserve the baseline.')
    data = read_json(SKILL / 'assets/legacy/render-manifest.template.json')
    data['assets'] = [{'path': path, 'sha256': digest(resolve(root, path))}
                      for path in asset_paths(brief)]
    save_json(output, data)
    return {'status': 'BASELINE_SAVED', 'path': str(output)}


def check(root, manifest_path):
    from PIL import Image
    errors, warnings, selected = [], [], []
    brief = read_json(root / 'brief.json')
    config = read_json(root / 'assets/fonts.json')
    inventory = scan(root)
    warnings.extend(['Unreadable inventory font: ' + x['path'] for x in inventory['errors']])
    manifest = read_json(resolve(root, manifest_path))
    canvas = brief.get('canvas', {'width': 1600, 'height': 2000})
    override = brief.get('exam_override')
    if override is not None:
        canvas = override
        if not override.get('source') or not override.get('evidence'):
            errors.append('Exam override needs teacher source and exact evidence.')
    width, height = canvas.get('width'), canvas.get('height')
    if type(width) is not int or type(height) is not int or min(width, height) <= 0:
        errors.append('Canvas requires positive integer width and height.')
    elif override is None and width * 5 != height * 4:
        errors.append('Without exam override the canvas must be exactly portrait 4:5.')

    product = brief.get('product', {})
    if not product.get('image'):
        errors.append('Original product image is required.')
    if not product.get('logo') and not product.get('logo_not_applicable_reason'):
        errors.append('Provide original logo or evidence why no logo applies.')
    originals = manifest.get('assets', [])
    for path in asset_paths(brief):
        try:
            absolute = resolve(root, path)
            records = [a for a in originals if resolve(root, a.get('path')) == absolute]
            if len(records) != 1 or records[0].get('sha256') != digest(absolute):
                errors.append('Original asset missing baseline or modified: ' + str(path))
        except Exception as exc:
            errors.append('Asset error: ' + str(exc))

    roles = config.get('roles', {})
    for language in ('zh', 'en'):
        copy = brief.get('copy', {}).get(language, [])
        blocks = manifest.get('text_blocks', {}).get(language, [])
        ids = [item.get('id') for item in copy]
        block_ids = [item.get('id') for item in blocks]
        if not copy or any(not isinstance(i, str) or not i for i in ids) or len(set(ids)) != len(ids):
            errors.append(language + ': empty copy, missing ids or duplicate ids.')
        if len(set(block_ids)) != len(block_ids) or set(block_ids) != set(ids):
            errors.append(language + ': rendered text ids must match copy exactly once.')
        for item in copy:
            identifier = language + ':' + str(item.get('id'))
            if item.get('status') != 'confirmed' or not item.get('source'):
                errors.append(identifier + ': unconfirmed text or missing source.')
            content = item.get('text')
            if not isinstance(content, str) or not content.strip():
                errors.append(identifier + ': missing text.')
                continue
            matched = [b for b in blocks if b.get('id') == item.get('id')]
            if len(matched) != 1:
                continue
            runs = matched[0].get('runs', [])
            if not runs or ''.join(r.get('text', '') for r in runs) != content:
                errors.append(identifier + ': rendered text differs from confirmed copy.')
            for run in runs:
                try:
                    role_name = run.get('font_role')
                    role = roles.get(role_name)
                    if not role:
                        raise ValueError('Missing font role ' + str(role_name))
                    text = run.get('text', '')
                    actual = resolve(root, run.get('font_path'))
                    candidates = [role.get('primary')] + role.get('fallbacks', [])
                    if role_name != 'fallback':
                        candidates += [roles.get('fallback', {}).get('primary')]
                        candidates += roles.get('fallback', {}).get('fallbacks', [])
                    candidates = list(dict.fromkeys(p for p in candidates if p))
                    chosen, attempts = None, []
                    for candidate in candidates:
                        try:
                            detail = font_info(root, candidate, text)
                            if detail['missing_characters']:
                                raise ValueError('Missing glyphs: ' + ''.join(detail['missing_characters']))
                            chosen = resolve(root, candidate)
                            break
                        except Exception as exc:
                            attempts.append({'path': candidate, 'error': str(exc)})
                    if chosen is None:
                        fallback = config.get('system_fallback', {})
                        if fallback.get('enabled') and fallback.get('reason'):
                            for path in fallback.get('paths', []):
                                try:
                                    detail = font_info(root, path, text)
                                    if detail['missing_characters']:
                                        raise ValueError('Missing glyphs: ' + ''.join(detail['missing_characters']))
                                    chosen = resolve(root, path)
                                    warnings.append(identifier + ': SYSTEM FONT FALLBACK: ' + str(path))
                                    break
                                except Exception as exc:
                                    attempts.append({'path': path, 'error': str(exc)})
                    if chosen is None:
                        raise ValueError('All configured fonts failed: ' + json.dumps(attempts, ensure_ascii=False))
                    if actual != chosen:
                        raise ValueError('Rendered font differs from first valid configured choice: ' + str(chosen))
                    primary = resolve(root, role['primary']) if role.get('primary') else None
                    if actual != primary:
                        if not run.get('fallback_reason'):
                            raise ValueError('Fallback used without an explicit reason')
                        warnings.append(identifier + ': FONT FALLBACK: ' + str(actual))
                    if run.get('font_sha256') != digest(actual):
                        raise ValueError('Missing or changed rendered font hash')
                    selected.append({'id': identifier, 'role': role_name, 'font': str(actual), 'attempts': attempts})
                except Exception as exc:
                    errors.append(identifier + ': ' + str(exc))

    outputs = manifest.get('outputs', [])
    if len(outputs) != 2 or sorted(o.get('language', '') for o in outputs) != ['en', 'zh']:
        errors.append('Default delivery requires exactly one zh PNG and one en PNG.')
    output_paths = []
    for entry in outputs:
        try:
            path = resolve(root, entry.get('path'))
            output_paths.append(path)
            with Image.open(path) as im:
                im.load()
                if im.format != 'PNG' or path.suffix.lower() != '.png':
                    errors.append(str(path) + ': not a PNG.')
                if im.size != (width, height):
                    errors.append(str(path) + ': wrong pixel dimensions ' + str(im.size))
        except Exception as exc:
            errors.append('Output error: ' + str(exc))
    if len(set(output_paths)) != len(output_paths):
        errors.append('Language versions cannot point to the same file.')
    for key in VISUAL_KEYS:
        record = manifest.get('visual_qa', {}).get(key, {})
        if record.get('status') != 'PASS' or not record.get('evidence', '').strip():
            errors.append('Visual review pending/failed: ' + key)
    report = {'status': 'FAIL' if errors else 'PASS', 'errors': errors,
              'warnings': warnings, 'font_checks': selected,
              'note': 'Automatic checks do not establish visual quality; visual evidence is human/agent supplied.'}
    save_json(root / 'output/preflight/check-report.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['init', 'scan-fonts', 'snapshot', 'check'])
    parser.add_argument('--project', required=True)
    parser.add_argument('--manifest', default='output/working/render-manifest.json')
    args = parser.parse_args()
    root = Path(args.project).resolve()
    try:
        if args.command == 'init':
            result = init(root)
        elif args.command == 'scan-fonts':
            result = scan(root)
        elif args.command == 'snapshot':
            result = snapshot(root, args.manifest)
        else:
            result = check(root, args.manifest)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1 if result.get('status') == 'FAIL' else 0
    except Exception as exc:
        print(json.dumps({'status': 'ERROR', 'error': str(exc)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    sys.exit(main())
