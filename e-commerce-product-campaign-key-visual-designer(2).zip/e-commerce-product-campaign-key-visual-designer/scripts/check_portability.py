"""Isolated cross-product configuration invocation; never calls an image model or certifies visual QA."""
from pathlib import Path
import argparse,tempfile,shutil,json,subprocess,sys,copy
from PIL import Image
from unified_workflow import read,write,locate,sha

def check(casesfile,out):
    cases=read(casesfile)['cases'];skill=Path(__file__).resolve().parents[1];report={'status':'PASS','visual_status':'NOT_TESTED','scope':'Real original assets/copy, portable planning and exact-font/layout validation only. No new posters or joint-model outputs.','cases':[],'software_checks':[]}
    assert len(cases)>=2,'At least two different product inputs'
    with tempfile.TemporaryDirectory(prefix='portable-campaign-skill-') as tmp:
        root=Path(tmp);portable=root/'skill';shutil.copytree(skill,portable,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        def execute(script,args):
            command=[sys.executable,str(portable/'scripts'/script)]+args;r=subprocess.run(command,capture_output=True,text=True,encoding='utf-8');assert r.returncode==0,(script,r.stdout,r.stderr);return r.stdout
        for index,case in enumerate(cases):
            original=Path(case['project']).resolve();current=root/f'case-{index}';current.mkdir();b=read(original/'brief.json');plan=read(locate(original,case['plan']));layout=read(locate(original,case['layout']))
            # Stage only current originals/font config/brief/plan/layout; no prior scene, poster or case script.
            for key,field in [('image','source'),('logo','logo')]:
                file=locate(original,b['product'][key]);destination='assets/originals/'+key+file.suffix;locate(current,destination).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,locate(current,destination));b['product'][key]=destination;plan[field]=destination
            plan['style_references']=[];write(current/'brief.json',b);write(current/'plan.json',plan)
            for asset in original.glob('assets/fonts/**/*'):
                if asset.is_file():target=current/asset.relative_to(original);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(asset,target)
            shutil.copyfile(original/'assets/fonts.json',current/'assets/fonts.json')
            for lang in layout['languages']:
                layout['languages'][lang]['assets']=[{'kind':'logo','path':b['product']['logo'],'position':[.02,.01],'size':[.1,.08]}]
            write(current/'layout.json',layout)
            execute('unified_workflow.py',['prepare','--project',str(current),'--plan','plan.json'])
            execute('precise_render.py',['--project',str(current),'--layout','layout.json','--validate-only'])
            inputs=read(current/'working/scene-pipeline/generation-inputs.json');colors=read(current/'working/scene-pipeline/color-analysis.json');receipt=read(current/'working/scene-pipeline/receipt.json');type_report=read(current/'working/precise-render-report.json')
            assert len(inputs['referenced_image_paths'])==1 and Path(inputs['referenced_image_paths'][0])==locate(current,b['product']['image'])
            assert all(Path(v).is_relative_to(current) for v in inputs['referenced_image_paths']),'Reference still depends on prior case directory'
            assert type_report['rendered_text']=={lang:[{'id':c['id'],'text':c['text']} for c in b['copy'][lang]] for lang in b['delivery']['languages']}
            feature_ids=plan['layout']['feature_groups'][0].get('copy_ids',[])
            varied=copy.deepcopy(plan);varied['layout']['feature_groups'][0]['copy_ids']=feature_ids[:1];write(current/'one-feature.json',varied)
            execute('unified_workflow.py',['prepare','--project',str(current),'--plan','one-feature.json','--work','working/one-feature'])
            # Another legal 4:5 resolution; all photography/layout data are configuration values, not Python edits.
            scaled=copy.deepcopy(plan);scaled['canvas']=[320,400];sx,sy=320/plan['canvas'][0],400/plan['canvas'][1]
            for key in ('headline_zone','product_name_zone','feature_zone','price_zone','cta_zone'):
                if scaled['layout'].get(key):scaled['layout'][key]=[v*(sx if i%2==0 else sy) for i,v in enumerate(scaled['layout'][key])]
            scaled['support']['anchor']=[scaled['support']['anchor'][0]*sx,scaled['support']['anchor'][1]*sy]
            scaled['photography']['product_bounds']=[v*(sx if i%2==0 else sy) for i,v in enumerate(scaled['photography']['product_bounds'])];scaled['photography']['visual_center']=[scaled['photography']['visual_center'][0]*sx,scaled['photography']['visual_center'][1]*sy]
            bb=copy.deepcopy(b);bb['delivery'].update(width=320,height=400);write(current/'brief.json',bb);write(current/'scaled.json',scaled)
            execute('unified_workflow.py',['prepare','--project',str(current),'--plan','scaled.json','--work','working/scaled'])
            execute('precise_render.py',['--project',str(current),'--layout','layout.json','--validate-only'])
            with Image.open(locate(current,b['product']['image'])) as raw:raw_size=list(raw.size)
            item={'label':case.get('label',b['product'].get('name')),'status':'CONFIG_PASS','visual_qa':'NOT_TESTED','brand':b['product'].get('brand'),'original_dimensions':raw_size,'original_sha256':sha(locate(current,b['product']['image'])),'logo_sha256':sha(locate(current,b['product']['logo'])),'brand_color_candidates':colors['logo_candidates'],'scene':plan['composition'],'camera':plan['camera'],'contact_anchor':plan['support']['anchor'],'palette':plan['palette'],'feature_ids':feature_ids,'copy_counts':{k:len(v) for k,v in b['copy'].items()},'copy_lengths':{k:{c['id']:len(c['text']) for c in v} for k,v in b['copy'].items()},'confirmed_copy':b['copy'],'canvas_variants':[plan['canvas'],[320,400]],'feature_count_variants':[len(feature_ids),1],'source_snapshot_bound_to_brief':bool(receipt.get('brief_sha256')),'case_dependency':'Only originals, brief, fonts, plan and layout copied; all execution from isolated copied Skill scripts. No case Python, old scene or poster copied.'}
            report['cases'].append(item)
    assert len({x['original_sha256'] for x in report['cases']})==len(cases),'Need different raw products'
    report['software_checks']=['Isolated Skill copy runs for two distinct actual product inputs','Original-first generation payload binds current raw image, logo and brief','Different logo colors, camera/material/scene/contact plans read dynamically','Full Chinese/English text lengths, price/date and role mappings validated','Feature group count changed through JSON only','Resolution changed with proportional plan update through JSON only','No case-specific Python or prior poster dependencies; no generated scene copied']
    write(out,report);return report

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--cases',required=True);a.add_argument('--out',required=True);x=a.parse_args();r=check(x.cases,x.out);print(json.dumps({'status':r['status'],'visual_status':r['visual_status'],'cases':len(r['cases']),'report':x.out},ensure_ascii=False,indent=2))
