"""Synthetic joint-flow records test; not an image model or poster-quality test."""
from pathlib import Path
import tempfile,copy,json
from PIL import Image
import unified_workflow as u
import scene_workflow as f
from selftest_scene import fixture

def run():
 checks=[]
 with tempfile.TemporaryDirectory() as tmp:
  r=Path(tmp);fixture(r);p=u.read(r/'scene-plan.json');p['render_mode']='unified_hero';p['fallback_reason']=None;p['identity_constraints']={'anatomy':'Synthetic only','protected_details':['synthetic label']};p['layout']={'headline_zone':[0,0,100,20],'feature_zone':[0,20,30,80],'feature_groups':[{'id':'features'}]}
  p['photography']={'product_bounds':[40,40,60,60],'visual_center':[50,50],'camera_height':'synthetic','depth_of_field':'synthetic','key_light':'synthetic','ambient_light':'synthetic'}
  u.write(r/'joint-plan.json',p);u.prepare(r,'joint-plan.json')
  Image.new('RGB',(100,125),'grey').save(r/'joint.png');q={'method':'product_referenced_joint_generation','tool':'synthetic fixture; NOT a real model call','prompt_path':'working/scene-pipeline/generation-plan.txt','tool_call_evidence':'Synthetic test only','referenced_image_paths':[p['source']]};u.write(r/'submission.json',q);u.ingest(r,'joint-plan.json','joint.png','submission.json')
  review={k:{'status':'PASS','evidence':'Synthetic fixture only; NOT real visual verification'} for k in u.REVIEWS};review['comparison_images']=['pipeline-product.png','joint.png'];review['detail_repairs']=[];u.write(r/'joint-review.json',review);u.accept(r,'joint-plan.json','joint.png','joint-review.json');record={'mode':'unified_hero','plan':'joint-plan.json','work':'working/scene-pipeline'};assert not f.check_record(r,record)
  checks.append('Unified prepare/input provenance/ingest/detail review/accept sequence accepted')
  bad=copy.deepcopy(q);bad['referenced_image_paths']=[];u.write(r/'bad-submit.json',bad)
  try:u.ingest(r,'joint-plan.json','joint.png','bad-submit.json')
  except AssertionError:pass
  else:raise AssertionError('Joint flow accepted no original reference')
  bad=copy.deepcopy(review);bad['structure_controls']['status']='FAIL';u.write(r/'bad-review.json',bad)
  try:u.accept(r,'joint-plan.json','joint.png','bad-review.json')
  except AssertionError:pass
  else:raise AssertionError('Wrong structure accepted')
  bad=copy.deepcopy(review);bad['detail_repairs']=[{'source':p['source'],'region':'whole','reason':'test','whole_product_reoverlay':True}];u.write(r/'bad-review.json',bad)
  try:u.accept(r,'joint-plan.json','joint.png','bad-review.json')
  except AssertionError:pass
  else:raise AssertionError('Whole product reoverlay accepted as joint')
  checks.append('No original reference, identity FAIL and whole-product reoverlay rejected')
  try:f.validate(r,p)
  except AssertionError:pass
  else:raise AssertionError('Legacy composer ran as default')
  Image.new('RGB',(100,125),'white').save(r/'joint.png');assert f.check_record(r,record)
  checks.append('Old default composer rejected and altered joint output invalidates acceptance')
 return {'status':'PASS','checks':checks,'scope':'Software records only; no model fidelity or natural photography certified'}
if __name__=='__main__':print(json.dumps(run(),indent=2))
