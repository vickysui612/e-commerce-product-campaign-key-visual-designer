"""Input-driven bilingual logo/text/icon layers. No product placement, shadows or preset layout."""
from pathlib import Path
import argparse,json,io,copy
from PIL import Image,ImageDraw,ImageFont,ImageOps
import preflight as p
import preflight_legacy as legacy
import feature_module

def choose_font(root,config,inventory,role,text):
    selected=config['roles'][role];general=config['roles'].get('fallback',{})
    candidates=list(dict.fromkeys(v for v in [selected.get('primary')]+selected.get('fallbacks',[])+[general.get('primary')]+general.get('fallbacks',[]) if v));failures=[]
    sf=config.get('system_fallback',{})
    if sf.get('enabled') and sf.get('reason'):candidates+=sf.get('paths',[])
    for value in candidates:
        try:
            info=legacy.font_info(root,value,text)
            if info['missing_characters']:raise ValueError('Missing glyphs: '+''.join(info['missing_characters']))
            absolute=p.locate(root,value);primary=p.locate(root,selected['primary']) if selected.get('primary') else None
            reason='' if absolute==primary else (selected.get('reason') or sf.get('reason') or '')
            if absolute!=primary and not reason:raise ValueError('Fallback requires explicit reason')
            local={p.locate(root,x['path']) for x in inventory['fonts']}
            if local and absolute not in local and not config.get('local_font_decision'):raise ValueError('Local fonts exist; configure a suitable local role or record local_font_decision')
            return absolute,reason,info
        except Exception as exc:failures.append(str(exc))
    raise ValueError('No usable font for '+role+': '+'; '.join(failures))

def wrap_exact(text,font,width):
    lines=[];line=''
    for char in text:
        if char=='\n':raise ValueError('Mother copy must not contain layout line breaks; specify runs instead')
        if line and font.getlength(line+char)>width:
            # Prefer a space boundary for English without deleting the space from the source runs.
            split=line.rfind(' ')+1
            if split>0:lines.append(line[:split]);line=line[split:]+char
            else:lines.append(line);line=char
        else:line+=char
        if font.getlength(line)>width:raise ValueError('A glyph exceeds text width; replan shared role size')
    if line:lines.append(line)
    assert ''.join(lines)==text
    return lines

def run(root,layoutfile,manifest='output/working/render-manifest.json',validate_only=False):
    root=Path(root).resolve();brief=p.read(root/'brief.json');layout=p.read(p.locate(root,layoutfile));fonts=p.read(root/'assets/fonts.json');inventory=legacy.scan(root)
    size=(brief['delivery']['width'],brief['delivery']['height']);assert min(size)>0 and brief['delivery']['format'].upper()=='PNG'
    w,h=size;space=layout.get('coordinate_space','normalized');assert space in ('normalized','pixels')
    def xy(pair):return tuple(round(v*dimension) for v,dimension in zip(pair,size)) if space=='normalized' else tuple(round(v) for v in pair)
    def width(value):return round(value*w) if space=='normalized' else round(value)
    languages=brief['delivery']['languages'];assert set(layout['languages'])==set(languages)
    report={'status':'CONFIG_VALIDATED' if validate_only else 'RENDERED','visual_status':'NOT_CHECKED','font_scan':inventory,'outputs':[],'geometry':{},'rendered_text':{},'text_blocks':{},'fonts_used':[],'limitations':'Layout, palette, icon files and language-specific runs come from current analysis. This renderer neither auto-designs composition nor proves visual QA.'}
    def feature_font(lang,token,value):
        style=layout['languages'][lang]['styles'][token];role=style['font_role'];file,reason,info=choose_font(root,fonts,inventory,role,value)
        fs=feature_module.font_size(layout,size,lang,token)
        assert fs>0
        face=ImageFont.truetype(str(file),fs)
        if style.get('variation_axes') is not None:face.set_variation_by_axes(style['variation_axes'])
        if not any(x['path']==str(file) for x in report['fonts_used']):report['fonts_used'].append({'path':str(file),'usage':role,'fallback_reason':reason,'license':'Use supplied license metadata; no redistribution'})
        return face,{'font_role':role,'font_path':str(file),'font_sha256':info['sha256'],'fallback_reason':reason,'variation_axes':style.get('variation_axes')}
    feature_plans=feature_module.plan_groups(layout,brief,size,feature_font,wrap_exact)
    report['feature_modules']=feature_module.serializable(feature_plans)
    if not validate_only:
        from scene_workflow import check_record
        assert not check_record(root,layout['scene_pipeline']),'Hero pipeline must be actually generated and reviewed before typesetting'
        hero=Image.open(p.locate(root,layout['hero'])).convert('RGBA');assert hero.size==size,'Adapt whole hero to task canvas first'
    for lang in languages:
        conf=layout['languages'][lang];styles=conf['styles'];items={x['id']:x for x in brief['copy'][lang]};blocks=conf['text_blocks']
        feature_rows=[r for group in feature_plans for r in group['rows'][lang]];ids=[x['copy_id'] for x in blocks]+[r['copy_id'] for r in feature_rows]
        assert len(ids)==len(items) and set(ids)==set(items),'All exact copy IDs required once, including feature modules'
        layer=Image.new('RGBA',size);geometry=[];records=[];rendered=[]
        for block in blocks:
            cid=block['copy_id'];mother=items[cid];assert mother['status'] in ('confirmed','confirmed_translation'),'Unconfirmed copy'
            runs=block['runs'];values=[r.get('text',mother['text'] if len(runs)==1 else None) for r in runs];assert all(isinstance(v,str) for v in values) and ''.join(values)==mother['text'],'Runs alter locked copy: '+cid
            actual=[]
            for r,text in zip(runs,values):
                style=styles[r['token']];role=style['font_role'];face,reason,info=choose_font(root,fonts,inventory,role,text)
                fs=round(style['size_ratio']*w) if 'size_ratio' in style else style['size_px'];assert fs>0
                font=ImageFont.truetype(str(face),fs)
                if style.get('variation_axes') is not None:font.set_variation_by_axes(style['variation_axes'])
                color=layout['colors'][style['color_role']];pos=xy(r['position']);lines=wrap_exact(text,font,width(r['width'])) if r.get('width') else [text]
                step=round(fs*style.get('leading',1.2));glyphboxes=[]
                for i,value in enumerate(lines):
                    at=(pos[0],pos[1]+step*i);b=ImageDraw.Draw(layer).textbbox(at,value,font=font,anchor='lt')
                    if value.strip():assert 0<=b[0]<b[2]<=w and 0<=b[1]<b[3]<=h,'Text overflow; replan shared role instead of silently shrinking: '+cid
                    ImageDraw.Draw(layer).text(at,value,font=font,fill=color,anchor='lt');glyphboxes.append(b)
                geometry.append({'copy_id':cid,'token':r['token'],'font_role':role,'size':fs,'line_boxes':glyphboxes,'lines':lines})
                actual.append({'text':text,'font_role':role,'font_path':str(face),'font_sha256':info['sha256'],'fallback_reason':reason,'variation_axes':style.get('variation_axes')})
                if not any(x['path']==str(face) for x in report['fonts_used']):report['fonts_used'].append({'path':str(face),'usage':role,'fallback_reason':reason,'license':'Use supplied license metadata; no font redistribution by this script'})
            records.append({'id':cid,'runs':actual});rendered.append({'id':cid,'text':''.join(x['text'] for x in actual)})
        feature_module.paint(layer,lang,feature_plans)
        for row in feature_rows:
            cid=row['copy_id'];actual=[row['title_font_record'],row['body_font_record']]
            records.append({'id':cid,'runs':actual});rendered.append({'id':cid,'text':row['title']['text']+row['body']['text']})
            geometry.append({'copy_id':cid,'feature_module':row['id'],'module_box':row['module_box'],'icon_box':row['icon_box'],'text_height':row['text_height'],'diameter_to_text_height':row['diameter_to_text_height'],'vertical_center_error':row['vertical_center_error']})
        for asset in conf.get('assets',[]):
            file=p.locate(root,asset['path']);assert file.is_file()
            assert asset['kind'] in ('logo','icon','graphic'),'Renderer only adds logo/type/icon/graphic layers'
            if asset['kind']=='icon':assert layout.get('manual_feature_module_reason'),'Use measured feature_groups for icons; manual alternative needs explicit style reason'
            assert file!=p.locate(root,brief['product']['image']),'Whole original product reoverlay is forbidden'
            if asset['kind']=='logo':assert file==p.locate(root,brief['product']['logo']),'Independent logo must be original file'
            assert not any(asset.get(k) for k in ('rotation','recolor','stretch')),'Logo/icon layer cannot be distorted'
            if validate_only:continue
            if file.suffix.lower()=='.svg':
                try:import cairosvg
                except (ImportError,OSError) as exc:raise RuntimeError('Exact SVG rasterization requires optional CairoSVG/runtime; provide faithful original raster asset and evidence, never redraw') from exc
                im=Image.open(io.BytesIO(cairosvg.svg2png(url=str(file)))).convert('RGBA')
            else:im=Image.open(file).convert('RGBA')
            if asset.get('crop'):im=im.crop(tuple(asset['crop']))
            x,y=xy(asset['position']);target=xy(asset['size']);im=ImageOps.contain(im,target)
            assert 0<=x and 0<=y and x+im.width<=w and y+im.height<=h,'Layer outside canvas'
            layer.alpha_composite(im,(x,y))
        report['geometry'][lang]=geometry;report['text_blocks'][lang]=sorted(records,key=lambda r:list(items).index(r['id']));report['rendered_text'][lang]=sorted(rendered,key=lambda r:list(items).index(r['id']))
        if not validate_only:
            result=hero.copy();result.alpha_composite(layer);out=p.locate(root,conf['output']);assert out!=p.locate(root,layout['hero']) and out not in [p.locate(root,brief['product'][k]) for k in ('image','logo')],'Do not overwrite hero/originals'
            assert not out.exists(),'Preserve existing output; choose new version name';out.parent.mkdir(parents=True,exist_ok=True);result.convert('RGB').save(out);report['outputs'].append({'language':lang,'path':conf['output'],'sha256':p.sha(out)})
    reportfile=p.locate(root,layout.get('report','working/precise-render-report.json'));p.write(reportfile,report)
    if not validate_only:
        mf=p.locate(root,manifest);m=p.read(mf) if mf.exists() else p.read(p.SKILL/'assets/render-manifest.template.json')
        from review_binding import invalidate
        invalidate(m, 'precise_render created new bilingual outputs')
        for key in ('outputs','rendered_text','text_blocks','fonts_used'):m[key]=report[key]
        m['scene_pipeline']=layout['scene_pipeline'];m['layout_audit']={'method':'measured','evidence':'Actual font/glyph/run widths and boxes; mother copy preserved; style tokens from current language layout, see report','report_path':str(reportfile)}
        p.write(mf,m)
    return report

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--project',required=True);a.add_argument('--layout',required=True);a.add_argument('--manifest',default='output/working/render-manifest.json');a.add_argument('--validate-only',action='store_true');x=a.parse_args();r=run(x.project,x.layout,x.manifest,x.validate_only);print(json.dumps({'status':r['status'],'visual_status':r['visual_status'],'outputs':r['outputs']},ensure_ascii=False,indent=2))
