"""Primitive synthetic pixel/font tests; no real product poster or visual acceptance."""
from pathlib import Path
import tempfile,copy,json
from PIL import Image,ImageDraw,ImageChops
import unified_workflow as u
import restore_details as repair
import inspect_images as inspect
import precise_render as render
import preflight as p
from selftest_scene import color_fixture
from selftest import build_font

def run():
    checks=[]
    with tempfile.TemporaryDirectory() as tmp:
        r=Path(tmp);p.init(r)
        source=Image.new('RGB',(100,100),'white');ImageDraw.Draw(source).rectangle((20,20,40,40),fill='red');source.save(r/'source.png');Image.new('RGB',(100,100),'grey').save(r/'hero.png')
        s={'source':'source.png','hero':'hero.png','region':'synthetic local label','reason':'Primitive fixture only','source_quad':[[20,20],[40,20],[40,40],[20,40]],'target_quad':[[50,50],[70,50],[70,70],[50,70]],'product_bounds':[5,5,95,95],'whole_product_reoverlay':False}
        # Repair before brief binding in this synthetic fixture.
        b=p.read(r/'brief.json');b['product']['image']='source.png';p.write(r/'brief.json',b)
        u.write(r/'repair.json',s);q=repair.repair(r,'repair.json','repaired.png');im=Image.open(r/'repaired.png');assert im.getpixel((60,60))==(255,0,0) and im.getpixel((90,90))==(128,128,128)
        checks.append('Local source mark transferred; unrelated hero pixels unchanged')
        x=copy.deepcopy(s);x['source_quad']=[[5,5],[94,5],[94,94],[5,94]];u.write(r/'bad.json',x)
        try:repair.repair(r,'bad.json','bad.png')
        except AssertionError:pass
        else:raise AssertionError('Whole body repair allowed')
        checks.append('Oversized whole-body repair blocked')
        u.write(r/'inspection.json',{'comparisons':[{'panel_size':[80,100],'images':[{'path':'source.png','label':'source'},{'path':'repaired.png','label':'repair'}]}],'details':[{'path':'repaired.png','crop':[.48,.48,.72,.72],'purpose':'synthetic mark'}]});q=inspect.inspect(r,'inspection.json');assert Image.open(q['comparisons'][0]).size==(160,100) and q['visual_status']=='NOT_CHECKED'
        checks.append('Comparison/crop output works without assigning visual PASS')
        build_font(r/'assets/fonts/zh/check.ttf','测试');build_font(r/'assets/fonts/en/check.ttf','AB ')
        f=p.read(r/'assets/fonts.json')
        for lang in ('zh','en'):f['roles'][lang+'_headline']['primary']=f'assets/fonts/{lang}/check.ttf'
        p.write(r/'assets/fonts.json',f);b['delivery'].update(width=100,height=125);b['product']['logo']='source.png'
        for lang,value in [('zh','测试'),('en','AB AB AB')]:b['copy'][lang]=[{'id':'title','text':value,'status':'confirmed'}]
        p.write(r/'brief.json',b)
        layout={'hero':'hero.png','coordinate_space':'normalized','colors':{'ink':'#111111'},'languages':{lang:{'output':f'{lang}.png','styles':{'H1':{'font_role':lang+'_headline','size_ratio':.1,'color_role':'ink'}},'text_blocks':[{'copy_id':'title','runs':[{'token':'H1','position':[.1,.1],'width':.5}]}]} for lang in ('zh','en')}}
        u.write(r/'layout.json',layout);q=render.run(r,'layout.json',validate_only=True);assert q['visual_status']=='NOT_CHECKED' and not q['outputs'] and q['rendered_text']['en'][0]['text']=='AB AB AB'
        bad=copy.deepcopy(layout);bad['languages']['zh']['text_blocks'][0]['runs'][0]['text']='测试测试';u.write(r/'bad-layout.json',bad)
        try:render.run(r,'bad-layout.json',validate_only=True)
        except AssertionError:pass
        else:raise AssertionError('Changed mother copy accepted')
        checks.append('Dynamic bilingual exact-copy/font/glyph/wrap validation; altered copy blocked')
        Image.new('RGB',(100,125),'grey').save(r/'hero.png')
        plan={'render_mode':'unified_hero','canvas':[100,125],'source':'source.png','logo':'source.png','camera':{k:'Synthetic input only' for k in ('angle','elevation','visible_surfaces','vertical_axis','perspective','base_geometry','lighting_direction','material_properties','evidence','limitations')},'identity_constraints':{'anatomy':'Synthetic primitive','protected_details':['test mark']},'layout':{'headline_zone':[0,0,90,30],'feature_zone':[0,30,30,90],'feature_groups':[{'id':'features','copy_ids':[]}]},'support':{'anchor':[60,100],'perspective_rationale':'synthetic plane'},'materials':{'strategy':'opaque fixture','limitations':'not photography'},'composition':{'mode':'synthetic','reason':'component test'},'photography':{'product_bounds':[40,40,80,110],'visual_center':[60,70],'camera_height':'synthetic','depth_of_field':'synthetic','key_light':'synthetic','ambient_light':'synthetic'},'palette':{'roles':{'primary':'grey'},'rationale':'synthetic'},'props':[]}
        plan['palette']=color_fixture(plan['logo']);u.write(r/'plan.json',plan);u.prepare(r,'plan.json');submission={'method':'product_referenced_joint_generation','tool':'Synthetic test only; no model call','prompt_path':'working/scene-pipeline/generation-plan.txt','tool_call_evidence':'Synthetic component fixture','referenced_image_paths':['source.png']};u.write(r/'submission.json',submission);u.ingest(r,'plan.json','hero.png','submission.json');review={k:{'status':'PASS','evidence':'Synthetic test only, not visual QA'} for k in u.REVIEWS};review['comparison_images']=['source.png','hero.png'];u.write(r/'review.json',review);u.accept(r,'plan.json','hero.png','review.json')
        layout['scene_pipeline']={'mode':'unified_hero','plan':'plan.json','work':'working/scene-pipeline'};u.write(r/'layout.json',layout);q=render.run(r,'layout.json');assert Image.open(r/'zh.png').size==(100,125) and len(q['outputs'])==2
        m=p.read(r/'output/working/render-manifest.json');assert all(m['gates'][key]['status']=='PENDING' and not m['gates'][key]['reviewed_outputs'] for key in ('T_layout_promotion','C_final')) and all(x['status']=='NOT_CHECKED' for x in m['visual_qa'].values())
        checks.append('Synthetic render exports distinct PNGs and leaves all visual/human gates unapproved')
        (r/'working/scene-pipeline/generation-plan.txt').write_text('changed prompt');assert u.check_record(r,layout['scene_pipeline'])
        checks.append('Changing actual generation prompt invalidates accepted receipt')
    return {'status':'PASS','checks':checks,'scope':'Synthetic component software tests only, no product visual QA'}

if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False,indent=2))
