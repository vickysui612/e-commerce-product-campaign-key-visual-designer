"""Brand/scene color-plan and review-record validation; cannot judge visual harmony from metadata."""
from pathlib import Path
import re

ROLES=('primary','secondary','accent','neutral','background_tone')
ANALYSIS=('logo_colors','product_colors','product_materials','target_audience','scene_mood','marketing_theme')
ENVIRONMENT={'background','support_surface','props','environment_light','decorative_graphics'}
TARGETS=ENVIRONMENT|{'icon','information','price_cta'}
CHECKS=('logo_color_source','scene_harmony','beyond_text','unified_color_system','brand_scene_style','logo_hidden_consistency')

def validate(root,plan):
    p=plan['palette']
    assert all(p.get('roles',{}).get(k) for k in ROLES),'Color System requires primary/secondary/accent/neutral/background_tone'
    assert all(p.get('analysis',{}).get(k) for k in ANALYSIS),'Analyze Logo, product color/material, audience, scene mood and marketing theme before generation'
    source=p.get('brand_color_source',{})
    assert source.get('method') in ('logo_sampled','official_standard','not_adopted') and source.get('evidence'),'Record actual brand-color source/decision'
    if p.get('brand_is_design_basis'):
        assert source['method']!='not_adopted','Brand basis needs actual selected source'
        assert source.get('selected_colors') and all(re.fullmatch(r'#[0-9a-fA-F]{6}',c) for c in source['selected_colors']),'Record selected brand colors'
        if source['method']=='logo_sampled':assert (Path(root)/source.get('reference','')).resolve()==(Path(root)/plan['logo']).resolve(),'Logo samples must come from original Logo'
        else:assert source.get('reference'),'Official color standard needs source reference'
        applications=p.get('scene_applications',[])
        assert applications and all(isinstance(a,dict) and a.get('target') in TARGETS and a.get('palette_role') in ROLES and a.get('treatment') and a.get('relationship') for a in applications),'Use structured color applications: target/palette_role/treatment/relationship'
        assert any(a['target'] in ENVIRONMENT for a in applications),'Brand color cannot stop at text/icon/price/CTA; at least one environmental connection required'
    return p

def qa_errors(record,palette):
    errors=[];checks=record.get('checks',{})
    for key in CHECKS:
        item=checks.get(key,{})
        if not item.get('evidence'):errors.append('Brand Color Harmony QA: missing actual evidence for '+key)
        status=item.get('status')
        na_allowed=(key=='logo_color_source' and palette.get('brand_color_source',{}).get('method')!='logo_sampled') or (not palette.get('brand_is_design_basis') and key in ('beyond_text','brand_scene_style','logo_hidden_consistency'))
        if status!='PASS' and not (status=='NOT_APPLICABLE' and na_allowed):errors.append('Brand Color Harmony QA: '+key+' not passed')
    return errors
