"""Bind typography and final reviews to actual output bytes; never create approval."""
from pathlib import Path
import argparse
import copy
import hashlib
import json

REVISION = 't-c-output-sha256-v1'
BOUND_GATES = ('T_layout_promotion', 'C_final')


def output_snapshot(root, outputs):
    records = []
    for item in outputs:
        language = item['language']
        if not isinstance(language, str) or not language or any(x['language'] == language for x in records):
            raise ValueError('Missing or duplicate output language')
        path = Path(root) / item['path']
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest() if hasattr(hashlib, 'file_digest') else hashlib.sha256(stream.read()).hexdigest()
        records.append({'language': language, 'sha256': digest})
    return records


def binding_errors(root, manifest, languages, gate_name):
    if gate_name not in BOUND_GATES:
        raise ValueError('Unknown bound review gate: ' + gate_name)
    prefix = gate_name + ' reviewed_outputs: '
    reviewed = manifest.get('gates', {}).get(gate_name, {}).get('reviewed_outputs')
    if not isinstance(reviewed, list) or not reviewed:
        return [prefix + 'missing output binding. Preserve historical approval; review the current candidates per references/project-schema.md. Never backfill approval automatically.']
    try:
        seen = {}
        for item in reviewed:
            if not isinstance(item, dict):
                raise ValueError('each review entry must be an object')
            language, digest = item.get('language'), item.get('sha256')
            if not isinstance(language, str) or language in seen:
                raise ValueError('missing/duplicate review language')
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
                raise ValueError('invalid SHA-256')
            seen[language] = digest
        current = {x['language']: x['sha256'] for x in output_snapshot(root, manifest.get('outputs', []))}
        if set(seen) != set(languages) or set(current) != set(languages) or seen != current:
            raise ValueError('reviewed bytes differ from current outputs; invalidate T and C and review the changed version')
    except (KeyError, TypeError, ValueError, OSError) as exc:
        return [prefix + str(exc)]
    return []


def invalidate(manifest, reason):
    """Retain previous evidence as history, clear T/C and every visual subcheck."""
    gates = manifest.setdefault('gates', {})
    prior = {name: copy.deepcopy(gates.get(name, {})) for name in BOUND_GATES}
    if any(g.get('status') in ('PASS', 'REVISE') or g.get('evidence') or g.get('reviewed_outputs') for g in prior.values()):
        manifest.setdefault('iterations', []).append({
            'action': 'invalidate_bound_reviews', 'reason': reason,
            'previous_T_layout_promotion': prior['T_layout_promotion'],
            'previous_C_final': prior['C_final'],
            'previous_outputs': copy.deepcopy(manifest.get('outputs', [])),
            'previous_visual_qa': copy.deepcopy(manifest.get('visual_qa', {}))})
    for name in BOUND_GATES:
        gates.setdefault(name, {}).update(status='PENDING', reviewer='', evidence='', object_version='', review_objects=[], pass_criteria=[], reviewed_outputs=[])
    def clear(record):
        if isinstance(record, dict):
            if 'status' in record:
                record.update(status='NOT_CHECKED', evidence='')
            for value in record.values():
                if isinstance(value, (dict, list)):
                    clear(value)
        elif isinstance(record, list):
            for value in record:
                clear(value)
    clear(manifest.get('visual_qa', {}))
    manifest['review_binding_revision'] = REVISION


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('snapshot', 'invalidate'))
    parser.add_argument('--project', required=True)
    parser.add_argument('--manifest', default='output/working/render-manifest.json')
    parser.add_argument('--reason')
    args = parser.parse_args()
    root = Path(args.project).resolve()
    path = root / args.manifest
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    if args.command == 'snapshot':
        print(json.dumps({'status': 'CANDIDATE_SNAPSHOT_ONLY', 'reviewed_outputs': output_snapshot(root, data['outputs']), 'note': 'No approval written. Capture before showing candidates; attach separately to T and C only after each actual same-version answer or authorized waiver.'}, ensure_ascii=False, indent=2))
    else:
        if not args.reason:
            parser.error('invalidate requires --reason')
        invalidate(data, args.reason)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'status': 'PENDING', 'manifest': str(path)}))
