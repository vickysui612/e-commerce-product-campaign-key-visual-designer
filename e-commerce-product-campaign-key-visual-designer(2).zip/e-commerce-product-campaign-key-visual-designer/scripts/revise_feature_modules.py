"""Replace only feature modules using existing posters and their exact clean hero; no scene generation."""
from pathlib import Path
import argparse,json,copy
from PIL import Image,ImageDraw,ImageChops
import precise_render as render
import preflight as p
from feature_module import plan_groups,paint,serializable,font_size

def revise(root,specfile,work='working/feature-revision'):
    root=Path(root).resolve();s=p.read(p.locate(root,specfile));brief=p.read(root/'brief.json');previous=Path(s['source_root']).resolve();mf=p.locate(previous,s['source_manifest']);old=p.read(mf);layout=p.read(p.locate(root,s['layout']));size=(brief['delivery']['width'],brief['delivery']['height'])
    # All facts/copy are locked for a component-only revision.
    for lang in brief['delivery']['languages']:
        assert {x['id']:x['text'] for x in old['rendered_text'][lang]}=={x['id']:x['text'] for x in brief['copy'][lang]},'Component revision cannot alter mother copy'
    for key in ('image','logo'):
        records=[a for a in old['assets'] if p.locate(previous,a['path'])==p.locate(previous,p.read(previous/'brief.json')['product'][key])]
        assert len(records)==1 and records[0]['sha256']==p.sha(p.locate(root,brief['product'][key])),'Original asset differs from prior rendering'
    hero_file=p.locate(previous,s['clean_hero']);hero=Image.open(hero_file).convert('RGB');assert hero.size==size
    # Reuse only the exact hero previously accepted by executor, with its original generation provenance.
    archived=p.read(p.locate(previous,s['hero_receipt']));assert archived['stage']=='HERO_ACCEPTED' and archived['output_sha256']==p.sha(hero_file)
    source_pipeline=p.locate(previous,old['scene_pipeline']['plan']);source_plan=p.read(source_pipeline)
    assert archived['source_sha256']==p.sha(p.locate(root,brief['product']['image'])) and archived['logo_sha256']==p.sha(p.locate(root,brief['product']['logo']))
    reviewfile=p.locate(previous,archived['review']);assert p.sha(reviewfile)==archived['review_sha256']
    from unified_workflow import REVIEWS
    assert all(p.read(reviewfile)[k]['status']=='PASS' and p.read(reviewfile)[k]['evidence'] for k in REVIEWS),'Prior hero identity/space review incomplete'
    fonts=p.read(root/'assets/fonts.json');inventory=render.legacy.scan(root);w,h=size;report={'status':'COMPONENT_REVISED','visual_status':'NOT_CHECKED','inputs':[],'outputs':[],'fonts_used':copy.deepcopy(old['fonts_used']),'rendered_text':{},'text_blocks':{},'geometry':{}}
    def load(lang,token,value):
        style=layout['languages'][lang]['styles'][token];file,reason,info=render.choose_font(root,fonts,inventory,style['font_role'],value);fs=font_size(layout,size,lang,token);font=render.ImageFont.truetype(str(file),fs)
        if style.get('variation_axes') is not None:font.set_variation_by_axes(style['variation_axes'])
        if not any(p.locate(root,x['path'])==file for x in report['fonts_used']):report['fonts_used'].append({'path':str(file),'usage':style['font_role'],'fallback_reason':reason,'license':'Installed/supplied; not redistributed'})
        return font,{'font_role':style['font_role'],'font_path':str(file),'font_sha256':info['sha256'],'fallback_reason':reason,'variation_axes':style.get('variation_axes')}
    plans=plan_groups(layout,brief,size,load,render.wrap_exact);report['feature_modules']=serializable(plans)
    protected=Image.open(p.locate(previous,s['product_protection_mask'])).convert('L').point(lambda v:255 if v else 0);assert protected.size==size
    folder=p.locate(root,work);folder.mkdir(parents=True,exist_ok=True)
    for lang in brief['delivery']['languages']:
        item=s['languages'][lang];source=p.locate(previous,item['source']);assert source==p.locate(previous,next(x['path'] for x in old['outputs'] if x['language']==lang)),'Revision source differs from archived poster'
        poster=Image.open(source).convert('RGB');assert poster.size==size;erase=Image.new('L',size);d=ImageDraw.Draw(erase)
        for box in item['erase_boxes']:
            assert len(box)==4 and 0<=box[0]<box[2]<=w and 0<=box[1]<box[3]<=h;d.rectangle(box,fill=255)
        assert not ImageChops.multiply(erase,protected).getbbox(),'Erase area intersects protected product'
        layer=Image.new('RGBA',size);paint(layer,lang,plans);touched=ImageChops.lighter(erase,layer.getchannel('A'))
        assert not ImageChops.multiply(touched,protected).getbbox(),'New feature module overlaps protected product'
        updated=Image.composite(hero,poster,erase).convert('RGBA');updated.alpha_composite(layer);updated=updated.convert('RGB')
        diff=ImageChops.difference(poster,updated);outside_mask=ImageChops.invert(touched).point(lambda v:255 if v==255 else 0);outside=ImageChops.multiply(diff,Image.merge('RGB',(outside_mask,outside_mask,outside_mask)));assert not outside.getbbox(),'Pixels outside feature edit changed'
        out=p.locate(root,item['output']);assert not out.exists(),'Preserve old/new versions; choose fresh output name';out.parent.mkdir(parents=True,exist_ok=True);updated.save(out)
        maskfile=folder/f'{lang}-edit-mask.png';touched.save(maskfile);report['inputs'].append({'path':str(source),'sha256':p.sha(source)});report['outputs'].append({'language':lang,'path':item['output'],'sha256':p.sha(out),'outside_edit_pixels':'IDENTICAL','product_pixels':'IDENTICAL','edit_mask':str(maskfile),'edit_mask_sha256':p.sha(maskfile)})
        rows=[r for g in plans for r in g['rows'][lang]];changed={r['copy_id'] for r in rows};records=[x for x in copy.deepcopy(old['text_blocks'][lang]) if x['id'] not in changed]
        for row in rows:records.append({'id':row['copy_id'],'runs':[row['title_font_record'],row['body_font_record']]})
        report['text_blocks'][lang]=records;report['rendered_text'][lang]=[{'id':x['id'],'text':''.join(r['text'] for r in x['runs'])} for x in records]
        updated.resize((320,400)).save(folder/f'{lang}-mobile.png')
    report.update(hero=str(hero_file),hero_sha256=p.sha(hero_file),source_manifest=str(mf),source_manifest_sha256=p.sha(mf),hero_receipt=str(p.locate(previous,s['hero_receipt'])),hero_receipt_sha256=p.sha(p.locate(previous,s['hero_receipt'])),hero_review=str(reviewfile),hero_review_sha256=p.sha(reviewfile),original_product_sha256=p.sha(p.locate(root,brief['product']['image'])),original_logo_sha256=p.sha(p.locate(root,brief['product']['logo'])),spec=specfile,spec_sha256=p.sha(p.locate(root,specfile)),layout=s['layout'],layout_sha256=p.sha(p.locate(root,s['layout'])),note='Only feature overlay revision. Prior jointly generated hero reused; no new model call, product regeneration or lighting change. New visual QA/human C required.')
    p.write(folder/'receipt.json',report);return report

def check_record(root,record):
    try:
        root=Path(root);r=p.read(p.locate(root,record['work'])/'receipt.json');assert r['status']=='COMPONENT_REVISED'
        for key in ('hero','source_manifest','hero_receipt','hero_review'):assert p.sha(Path(r[key]))==r[key+'_sha256'],'Prior '+key+' changed'
        for key in ('spec','layout'):assert p.sha(p.locate(root,r[key]))==r[key+'_sha256'],key+' changed'
        for v in r['inputs']+r['outputs']:assert p.sha(p.locate(root,v['path']))==v['sha256'],'Revision pixel artifact changed'
        for out in r['outputs']:assert p.sha(Path(out['edit_mask']))==out['edit_mask_sha256'] and out['outside_edit_pixels']=='IDENTICAL' and out['product_pixels']=='IDENTICAL'
        return []
    except Exception as exc:return ['component_revision: '+str(exc)]

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--project',required=True);a.add_argument('--spec',required=True);a.add_argument('--work',default='working/feature-revision');x=a.parse_args();r=revise(x.project,x.spec,x.work);print(json.dumps({'status':r['status'],'outputs':r['outputs']},ensure_ascii=False,indent=2))
