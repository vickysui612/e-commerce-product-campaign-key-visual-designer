"""Source-derived LOCAL imprint restoration; not a whole-product compositor or 3D transform."""
from pathlib import Path
import argparse,json,math
from PIL import Image,ImageDraw,ImageFilter
from unified_workflow import read,write,locate,sha

def solve(matrix,values):
    a=[list(map(float,row))+[float(value)] for row,value in zip(matrix,values)]
    for col in range(len(values)):
        pivot=max(range(col,len(a)),key=lambda row:abs(a[row][col]));a[col],a[pivot]=a[pivot],a[col]
        assert abs(a[col][col])>1e-10,'Degenerate local surface mapping'
        div=a[col][col];a[col]=[v/div for v in a[col]]
        for row in range(len(a)):
            if row!=col:
                factor=a[row][col];a[row]=[v-factor*w for v,w in zip(a[row],a[col])]
    return [row[-1] for row in a]

def bounds(quad,size):
    assert len(quad)==4 and all(len(q)==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in q) for q in quad)
    xs,ys=zip(*quad);b=(min(xs),min(ys),max(xs),max(ys));assert 0<=b[0]<b[2]<size[0] and 0<=b[1]<b[3]<size[1],'Quad outside image';return b

def repair(root,specfile,out,work='working/detail-repair'):
    root=Path(root).resolve();s=read(locate(root,specfile));assert s.get('reason') and s.get('region'),'Name local protected region and reason'
    assert not s.get('whole_product_reoverlay'),'Whole-product replacement forbidden'
    sourcefile=locate(root,s['source']);herofile=locate(root,s['hero']);output=locate(root,out)
    assert output not in (sourcefile,herofile),'Keep raw source and unrepaired candidate'
    if locate(root,'brief.json').exists():assert sourcefile==locate(root,read(locate(root,'brief.json'))['product']['image']),'Repair must use current original source'
    src=Image.open(sourcefile).convert('RGB');hero=Image.open(herofile).convert('RGB');sq=s['source_quad'];tq=s['target_quad'];sb=bounds(sq,src.size);tb=bounds(tq,hero.size)
    pb=s['product_bounds'];assert len(pb)==4 and pb[2]>pb[0] and pb[3]>pb[1]
    assert pb[0]<=sb[0] and pb[1]<=sb[1] and sb[2]<=pb[2] and sb[3]<=pb[3],'Source repair outside product bounds'
    fraction=(sb[2]-sb[0])*(sb[3]-sb[1])/((pb[2]-pb[0])*(pb[3]-pb[1]));assert fraction<=.25,'Region exceeds local-repair guard; regenerate identity instead of replacing body'
    a=[];b=[]
    for (x,y),(u,v) in zip(tq,sq):a.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
    coefficients=solve(a,b);patch=src.transform(hero.size,Image.Transform.PERSPECTIVE,coefficients,Image.Resampling.BICUBIC)
    factors=s.get('illumination_factors',[1,1,1]);assert len(factors)==3 and all(.9<=v<=1.1 for v in factors),'Only mild documented illumination, no recoloring'
    patch=Image.merge('RGB',[channel.point(lambda value,f=f:round(min(255,value*f))) for channel,f in zip(patch.split(),factors)])
    blur=s.get('edge_feather_px',0);assert 0<=blur<=min(tb[2]-tb[0],tb[3]-tb[1])*.02,'Feather exceeds local boundary'
    # Feather is clipped inside the repair polygon so unrelated body pixels stay protected.
    hard=Image.new('L',hero.size);ImageDraw.Draw(hard).polygon([tuple(q) for q in tq],fill=255);mask=hard.filter(ImageFilter.GaussianBlur(blur))
    from PIL import ImageChops
    mask=ImageChops.multiply(mask,hard);result=Image.composite(patch,hero,mask);output.parent.mkdir(parents=True,exist_ok=True);result.save(output)
    folder=locate(root,work);folder.mkdir(parents=True,exist_ok=True);mask.save(folder/'repair-mask.png')
    report={'source':s['source'],'hero':s['hero'],'region':s['region'],'reason':s['reason'],'source_quad':sq,'target_quad':tq,'source_sha256':sha(sourcefile),'hero_sha256':sha(herofile),'output':out,'output_sha256':sha(output),'whole_product_reoverlay':False,'source_region_area_fraction':fraction,'inverse_perspective_coefficients':coefficients,'illumination_factors':factors,'edge_feather_px':blur,'visual_status':'NOT_CHECKED','limitations':'Local imprint surface mapping only. No whole-product camera change. Original resolution limits remain; actual comparison required.'}
    write(folder/'repair.json',report);return report

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--project',required=True);a.add_argument('--spec',required=True);a.add_argument('--out',required=True);a.add_argument('--work',default='working/detail-repair');x=a.parse_args();print(json.dumps(repair(x.project,x.spec,x.out,x.work),ensure_ascii=False,indent=2))
