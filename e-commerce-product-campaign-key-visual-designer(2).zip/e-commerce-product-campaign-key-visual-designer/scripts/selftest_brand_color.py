"""Color-plan/QA gate tests only; not actual visual harmony verification."""
import copy,json,tempfile
from pathlib import Path
from PIL import Image
import color_strategy as c
from selftest_scene import color_fixture

def run():
    checks=[]
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);Image.new('RGB',(12,12),(20,50,140)).save(root/'logo.png');plan={'logo':'logo.png','palette':color_fixture('logo.png')};c.validate(root,plan)
        checks.append('Logo-derived color with neutral environment relationship accepted; scene need not equal Logo hue')
        for target in ('icon','information','price_cta'):
            bad=copy.deepcopy(plan);bad['palette']['scene_applications'][0]['target']=target
            try:c.validate(root,bad)
            except AssertionError:pass
            else:raise AssertionError('Text/icon-only brand application accepted')
        checks.append('Icon/information/price-CTA alone cannot masquerade as scene application')
        for key in c.ROLES:
            bad=copy.deepcopy(plan);bad['palette']['roles'].pop(key)
            try:c.validate(root,bad)
            except AssertionError:pass
            else:raise AssertionError('Incomplete color system accepted')
        bad=copy.deepcopy(plan);bad['palette']['brand_color_source']['reference']='unrelated.png'
        try:c.validate(root,bad)
        except AssertionError:pass
        else:raise AssertionError('Unrelated logo color source accepted')
        checks.append('Incomplete five-role system and incorrect original Logo source rejected')
        review={'checks':{key:{'status':'PASS','evidence':'Synthetic test evidence, not actual image QA'} for key in c.CHECKS}}
        assert not c.qa_errors(review,plan['palette'])
        for key in c.CHECKS:
            for status in ('FAIL','REVISE','NOT_CHECKED','NOT_APPLICABLE'):
                bad=copy.deepcopy(review);bad['checks'][key]['status']=status;assert c.qa_errors(bad,plan['palette'])
            bad=copy.deepcopy(review);bad['checks'][key]['evidence']='';assert c.qa_errors(bad,plan['palette'])
        checks.append('Six color reviews including Logo-hidden consistency require PASS/evidence for adopted Logo color')
        official=copy.deepcopy(plan);official['palette']['brand_color_source'].update(method='official_standard',reference='official specification source');c.validate(root,official)
        review['checks']['logo_color_source'].update(status='NOT_APPLICABLE',evidence='Official specification used, no false claim of Logo sampling')
        assert not c.qa_errors(review,official['palette'])
        review['checks']['scene_harmony']['status']='FAIL';assert c.qa_errors(review,official['palette'])
        checks.append('Official-source exception does not waive scene harmony')
    return {'status':'PASS','checks':checks,'scope':'Synthetic schema/gate checks, no poster generated or visual harmony certified'}

if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False,indent=2))
