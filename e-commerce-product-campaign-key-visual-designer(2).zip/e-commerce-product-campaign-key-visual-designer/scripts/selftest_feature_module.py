"""Synthetic component measurement/drawing tests; no product poster or visual brand QA."""
from pathlib import Path
import copy,json,tempfile
from PIL import Image,ImageFont
import precise_render as render
import feature_module as f
import preflight as p
from selftest import build_font

def setup(root):
    p.init(root);build_font(root/'assets/fonts/zh/test.ttf','测试说明 ');build_font(root/'assets/fonts/en/test.ttf','AB ')
    fonts=p.read(root/'assets/fonts.json')
    for lang in ('zh','en'):
        for role in ('secondary','body'):fonts['roles'][lang+'_'+role]['primary']=f'assets/fonts/{lang}/test.ttf'
    p.write(root/'assets/fonts.json',fonts);brief=p.read(root/'brief.json');brief['delivery'].update(width=360,height=420);brief['product'].update(image='raw.png',logo='logo.png')
    Image.new('RGB',(12,12),'grey').save(root/'raw.png');Image.new('RGB',(12,12),'blue').save(root/'logo.png')
    items=[]
    for index in range(3):
        copies={}
        for lang,title,body in [('zh','测试','说明'),('en','AB ','BA')]:
            cid=f'feature-{index}';brief['copy'][lang].append({'id':cid,'text':title+body,'status':'confirmed'});copies[lang]={'copy_id':cid,'title':title,'body':body}
        items.append({'id':str(index),'semantic_evidence':'Synthetic glyph/copy fixture only, not product claim','copy':copies,'glyph':[{'kind':'polyline','points':[[.2,.8],[.5,.2],[.8,.8]]},{'kind':'line','points':[[.35,.65],[.65,.65]]}]})
    layout={'coordinate_space':'normalized','colors':{'brand':'#245646','title':'#173c31','body':'#405c53'},'languages':{lang:{'output':f'{lang}.png','styles':{'H3':{'font_role':lang+'_secondary','size_px':30,'color_role':'title'},'Body':{'font_role':lang+'_body','size_px':24,'color_role':'body'}},'text_blocks':[],'assets':[]} for lang in ('zh','en')},'feature_groups':[{'id':'features','background_color_role':'brand','color_rationale':'Synthetic coordinated palette','languages':{lang:{'position':[.06,.06],'text_width':.65,'group_gap':.035,'title_token':'H3','body_token':'Body'} for lang in ('zh','en')},'items':items}]}
    p.write(root/'brief.json',brief);p.write(root/'layout.json',layout);return brief,layout

def run():
    checks=[]
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);brief,layout=setup(root);q=render.run(root,'layout.json',validate_only=True);group=q['feature_modules'][0]
        assert group['container_shape']=='circle' and group['foreground']=='white' and group['contrast_ratio']>=3
        heights=[r['text_height'] for rows in group['rows'].values() for r in rows]
        for rows in group['rows'].values():
            for row in rows:assert row['vertical_center_error']<.001 and .85<=row['diameter_to_text_height']<=1.10
        assert len({r['icon_box'][2]-r['icon_box'][0] for rows in group['rows'].values() for r in rows})==1
        checks.append('One bilingual diameter computed from full title+body height; centred, ratio .85–1.10 and shared metrics')
        assert q['rendered_text']=={lang:[{'id':c['id'],'text':c['text']} for c in brief['copy'][lang]] for lang in ('zh','en')}
        assert all(r['runs'][0]['font_role']==lang+'_secondary' and r['runs'][1]['font_role']==lang+'_body' for lang in ('zh','en') for r in q['text_blocks'][lang])
        checks.append('Exact bilingual mother copy and consistent H3/Body role/font records preserved')
        icon=f.glyph_icon(group,layout['feature_groups'][0]['items'][0]['glyph']);assert icon.getpixel((0,0))[3]==0
        centre=int(group['diameter_px']/2);assert icon.getpixel((centre,round(group['diameter_px']*.1)))[3]>240
        assert group['diameter_px']>max(heights)*.85
        checks.append('Actual filled-circle pixels drawn; glyph normalized into centred inner area')
        bad=copy.deepcopy(layout);bad['colors']['brand']='#ffffff';bad['colors']['white']='white';bad['feature_groups'][0]['foreground_color_role']='white';p.write(root/'bad.json',bad)
        try:render.run(root,'bad.json',validate_only=True)
        except AssertionError:pass
        else:raise AssertionError('Low contrast accepted')
        bad=copy.deepcopy(layout);bad['feature_groups'][0]['items'][0]['copy']['en']['body']='AB';p.write(root/'bad.json',bad)
        try:render.run(root,'bad.json',validate_only=True)
        except AssertionError:pass
        else:raise AssertionError('Invented/changed explanation accepted')
        checks.append('Low contrast and changed feature explanation rejected')
        long=copy.deepcopy(brief);long['copy']['en'][0]['text']='AB '+'AB '*18;p.write(root/'brief.json',long);bad=copy.deepcopy(layout);bad['feature_groups'][0]['items'][0]['copy']['en']['body']='AB '*18;bad['feature_groups'][0]['languages']['en']['text_width']=.16;p.write(root/'bad.json',bad)
        try:render.run(root,'bad.json',validate_only=True)
        except AssertionError as exc:assert 'Wrapped text heights' in str(exc)
        else:raise AssertionError('Unbalanced wrapped text accepted without replan')
        checks.append('Overlong English prompts width/layout replan; no item-specific icon resize or font shrink')
        p.write(root/'brief.json',brief);bad=copy.deepcopy(layout);bad['feature_groups'][0]['container_shape']='rounded_square';p.write(root/'bad.json',bad)
        try:render.run(root,'bad.json',validate_only=True)
        except AssertionError:pass
        else:raise AssertionError('Unjustified alternative container accepted')
        bad['feature_groups'][0]['style_exception_reason']='Synthetic style test, no real brand approval';p.write(root/'bad.json',bad);assert render.run(root,'bad.json',validate_only=True)['feature_modules'][0]['container_shape']=='rounded_square'
        checks.append('Alternative container requires explicit rationale and keeps same module geometry')
        review={'feature_checks':{key:{'status':'PASS','evidence':'Synthetic test only, not actual visual review'} for key in f.QA_KEYS}};assert not f.qa_errors(review)
        for key in f.QA_KEYS:
            bad=copy.deepcopy(review);bad['feature_checks'][key]['status']='FAIL';assert f.qa_errors(bad)
        checks.append('Six feature reviews cannot pass with missing/failed alignment, metrics, semantics or bilingual balance')
    return {'status':'PASS','checks':checks,'scope':'Synthetic icon/text component pixels and deterministic checks only; no product poster generated/verified'}

if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False,indent=2))
