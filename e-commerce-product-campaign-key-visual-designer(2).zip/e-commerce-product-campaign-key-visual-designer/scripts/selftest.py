"""Exercise preflight invariants with synthetic fonts/assets, never real posters."""
import copy
import json
from pathlib import Path
import tempfile

from PIL import Image
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
import preflight_legacy as p


def build_font(path, characters):
    cmap = {ord(c): 'u' + format(ord(c), 'X') for c in characters}
    glyph_order = ['.notdef'] + list(cmap.values())
    builder = FontBuilder(1000, isTTF=True)
    builder.setupGlyphOrder(glyph_order)
    builder.setupCharacterMap(cmap)
    glyphs = {}
    for name in glyph_order:
        pen = TTGlyphPen(None)
        if name != 'u20':
            pen.moveTo((100, 0)); pen.lineTo((100, 700))
            pen.lineTo((500, 700)); pen.lineTo((500, 0)); pen.closePath()
        glyphs[name] = pen.glyph()
    builder.setupGlyf(glyphs)
    builder.setupHorizontalMetrics({name: (600, 0) for name in glyph_order})
    builder.setupHorizontalHeader(ascent=800, descent=-200)
    builder.setupNameTable({'familyName': 'Synthetic QA Fixture', 'styleName': 'Regular',
                            'uniqueFontIdentifier': 'qa-fixture', 'fullName': 'Synthetic QA Fixture',
                            'psName': 'SyntheticQAFixture'})
    builder.setupOS2(sTypoAscender=800, sTypoDescender=-200, usWinAscent=800, usWinDescent=200)
    builder.setupPost()
    builder.save(path)


def run():
    results = []
    with tempfile.TemporaryDirectory(prefix='campaign-skill-test-') as tmp:
        root = Path(tmp)
        p.init(root)
        assert not p.scan(root)['fonts']
        results.append('Empty font directories are reported without invented fonts')
        build_font(root / 'assets/fonts/zh/fixture.ttf', 'AB测试')
        build_font(root / 'assets/fonts/en/fixture.ttf', 'AB')
        inventory = p.scan(root)
        assert len(inventory['fonts']) == 2 and not inventory['errors']
        results.append('Local TTF metadata and renderer loading are scanned')
        brief = p.read_json(root / 'brief.json')
        brief['canvas'] = {'width': 100, 'height': 125}
        brief['product'].update(image='product.png', logo='logo.png')
        for file in ('product.png', 'logo.png'):
            Image.new('RGB', (12, 12), 'red').save(root / file)
        config = p.read_json(root / 'assets/fonts.json')
        for lang, text in [('zh', '测试'), ('en', 'AB')]:
            brief['copy'][lang] = [{'id': 'title', 'text': text, 'role': 'headline',
                                  'source': 'Synthetic test only', 'status': 'confirmed'}]
            config['roles'][lang + '_headline']['primary'] = 'assets/fonts/' + lang + '/fixture.ttf'
        p.save_json(root / 'brief.json', brief)
        p.save_json(root / 'assets/fonts.json', config)
        p.snapshot(root, 'manifest.json')
        manifest = p.read_json(root / 'manifest.json')
        for lang in ('zh', 'en'):
            font = config['roles'][lang + '_headline']['primary']
            manifest['text_blocks'][lang] = [{'id': 'title', 'runs': [{
                'text': brief['copy'][lang][0]['text'], 'font_role': lang + '_headline',
                'font_path': font, 'font_sha256': p.digest(root / font), 'fallback_reason': ''}]}]
            Image.new('RGB', (100, 125), 'white').save(root / (lang + '.png'))
            manifest['outputs'].append({'language': lang, 'path': lang + '.png'})
        for key in p.VISUAL_KEYS:
            manifest['visual_qa'][key] = {'status': 'PASS', 'evidence': 'Synthetic test fixture, not real visual QA'}

        def check(b=brief, m=manifest, f=config):
            p.save_json(root / 'brief.json', b)
            p.save_json(root / 'manifest.json', m)
            p.save_json(root / 'assets/fonts.json', f)
            return p.check(root, 'manifest.json')

        assert check()['status'] == 'PASS'
        results.append('Consistent default 4:5 bilingual fixture passes deterministic checks')
        changed = copy.deepcopy(manifest)
        changed['text_blocks']['en'][0]['runs'][0]['text'] = 'A'
        assert any('differs from confirmed copy' in e for e in check(m=changed)['errors'])
        results.append('Changed or omitted copy is blocked')
        changed = copy.deepcopy(brief)
        changed['canvas'] = {'width': 100, 'height': 100}
        assert any('exactly portrait 4:5' in e for e in check(b=changed)['errors'])
        for lang in ('zh', 'en'):
            Image.new('RGB', (100, 100), 'white').save(root / (lang + '.png'))
        changed['exam_override'] = {'width': 100, 'height': 100, 'source': 'Synthetic teacher task',
                                    'evidence': 'Exam canvas 1:1'}
        assert check(b=changed)['status'] == 'PASS'
        results.append('1:1 requires explicit teacher evidence and then overrides 4:5')
        for lang in ('zh', 'en'):
            Image.new('RGB', (100, 125), 'white').save(root / (lang + '.png'))
        changed = copy.deepcopy(config)
        changed['roles']['zh_headline']['primary'] = 'assets/fonts/en/fixture.ttf'
        assert any('Missing glyphs' in e for e in check(f=changed)['errors'])
        results.append('A loadable font without required Chinese glyphs fails')
        changed['roles']['zh_headline']['fallbacks'] = ['assets/fonts/zh/fixture.ttf']
        assert any('without an explicit reason' in e for e in check(f=changed)['errors'])
        changed_manifest = copy.deepcopy(manifest)
        changed_manifest['text_blocks']['zh'][0]['runs'][0]['fallback_reason'] = 'Primary lacks Chinese glyphs'
        report = check(m=changed_manifest, f=changed)
        assert report['status'] == 'PASS' and report['warnings']
        results.append('Configured glyph fallback requires explicit disclosure')
        changed = copy.deepcopy(manifest)
        changed['visual_qa']['typography']['status'] = 'FAIL'
        assert any('typography' in e for e in check(m=changed)['errors'])
        results.append('Failed typography review blocks final readiness')
        for status in (None, 'NOT_CHECKED', 'FAIL'):
            changed = copy.deepcopy(manifest)
            if status is None:
                changed['visual_qa'].pop('contact_grounding')
            else:
                changed['visual_qa']['contact_grounding']['status'] = status
            report = check(m=changed)
            assert report['status'] == 'FAIL'
            assert any('contact_grounding' in e for e in report['errors'])
        changed = copy.deepcopy(manifest)
        changed['visual_qa']['contact_grounding']['evidence'] = ''
        assert check(m=changed)['status'] == 'FAIL'
        assert check()['status'] == 'PASS'
        results.append('Missing, pending, failed or evidence-free contact review blocks export readiness')
        for status in (None, 'NOT_CHECKED', 'FAIL'):
            changed = copy.deepcopy(manifest)
            if status is None:
                changed['visual_qa'].pop('typography_layout')
            else:
                changed['visual_qa']['typography_layout']['status'] = status
            assert any('typography_layout' in e for e in check(m=changed)['errors'])
        changed = copy.deepcopy(manifest)
        changed['visual_qa']['typography_layout']['evidence'] = ''
        assert any('typography_layout' in e for e in check(m=changed)['errors'])
        assert check()['status'] == 'PASS'
        results.append('Missing, pending, failed or evidence-free layout review blocks readiness')
        Image.new('RGB', (12, 12), 'blue').save(root / 'product.png')
        assert any('modified' in e for e in check()['errors'])
        results.append('Changes to original product bytes are detected')
    return {'status': 'PASS', 'checks': results,
            'scope': 'Synthetic deterministic tests only; no actual campaign or visual quality certification.'}


if __name__ == '__main__':
    print(json.dumps(run(), ensure_ascii=False, indent=2))
