"""Parameterized original/candidate comparisons and detail crops; no visual PASS inference."""
from pathlib import Path
import argparse,json
from PIL import Image,ImageOps,ImageDraw
from unified_workflow import read,write,locate,sha

def box(value,size,space='normalized'):
    assert len(value)==4
    x0,y0,x1,y1=value
    if space=='normalized':x0,x1=x0*size[0],x1*size[0];y0,y1=y0*size[1],y1*size[1]
    elif space!='pixels':raise ValueError('coordinate_space must be normalized or pixels')
    result=tuple(round(v) for v in (x0,y0,x1,y1))
    assert 0<=result[0]<result[2]<=size[0] and 0<=result[1]<result[3]<=size[1],'Inspection crop outside image'
    return result

def inspect(root,specfile,work='working/inspection'):
    root=Path(root).resolve();spec=read(locate(root,specfile));out=locate(root,work);out.mkdir(parents=True,exist_ok=True)
    report={'status':'INSPECTION_ASSETS_CREATED','visual_status':'NOT_CHECKED','comparisons':[],'details':[],'inputs':[]}
    for i,group in enumerate(spec.get('comparisons',[])):
        panels=[];width,height=group.get('panel_size',[480,560])
        for item in group['images']:
            src=locate(root,item['path']);im=Image.open(src).convert('RGB');region=box(item['crop'],im.size,item.get('coordinate_space','normalized')) if item.get('crop') else (0,0,*im.size)
            tile=Image.new('RGB',(width,height),'white');sample=ImageOps.contain(im.crop(region),(width,height-30));tile.paste(sample,((width-sample.width)//2,30));ImageDraw.Draw(tile).text((8,8),item.get('label',str(len(panels))),fill='black');panels.append(tile)
            report['inputs'].append({'path':item['path'],'sha256':sha(src),'crop_pixels':region})
        board=Image.new('RGB',(width*len(panels),height),'white')
        for j,tile in enumerate(panels):board.paste(tile,(width*j,0))
        file=out/f'comparison-{i+1}.png';board.save(file);report['comparisons'].append(str(file))
    for i,item in enumerate(spec.get('details',[])):
        src=locate(root,item['path']);im=Image.open(src);region=box(item['crop'],im.size,item.get('coordinate_space','normalized'));file=out/f'detail-{i+1}.png';im.crop(region).save(file)
        report['details'].append({'path':str(file),'purpose':item['purpose'],'source':item['path'],'source_sha256':sha(src),'crop_pixels':region})
    assert report['comparisons'] or report['details'],'No inspection views requested'
    write(out/'inspection.json',report);return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--project',required=True);parser.add_argument('--spec',required=True);parser.add_argument('--work',default='working/inspection');args=parser.parse_args();print(json.dumps(inspect(args.project,args.spec,args.work),ensure_ascii=False,indent=2))
