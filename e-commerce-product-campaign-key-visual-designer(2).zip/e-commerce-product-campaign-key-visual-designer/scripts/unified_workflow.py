"""Product-referenced unified photographic hero workflow.
The image-generation tool is called by the agent with the prepared raw reference inputs.
This helper records real inputs/output provenance and actual identity/space review;
it neither generates a product locally nor certifies perception from file hashes.
"""
from pathlib import Path
import argparse,json,hashlib,math
from PIL import Image

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def locate(r,v):return (Path(r)/v).resolve()
IDENTITY=('silhouette_proportions','structure_controls','original_color','embedded_marks_text','transparent_reflective_regions')
REVIEWS=IDENTITY+('contact_weight','perspective','lighting_materials','product_prop_hierarchy','information_regions','brand_scene_color')
def validate(root,p):
 assert p.get('render_mode','unified_hero')=='unified_hero','Wrong workflow'
 for k in ('source','logo'):assert locate(root,p[k]).is_file(),'Missing original '+k
 assert len(p['canvas'])==2 and all(type(v)==int and v>0 for v in p['canvas'])
 for k in ('angle','elevation','visible_surfaces','vertical_axis','perspective','base_geometry','lighting_direction','material_properties','evidence','limitations'):assert p['camera'].get(k),'Missing camera/material '+k
 assert p['identity_constraints'].get('anatomy') and p['identity_constraints'].get('protected_details'),'Describe actual identity and inspectable details'
 assert p['layout'].get('headline_zone') and p['layout'].get('feature_zone'),'Concentrated information zones required'
 assert len(p['layout'].get('feature_groups',[]))==1,'Default one cohesive feature group; do not fragment features'
 for key in ('headline_zone','feature_zone'):
  box=p['layout'][key];assert len(box)==4 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in box),'Invalid '+key
  assert 0<=box[0]<box[2]<=p['canvas'][0] and 0<=box[1]<box[3]<=p['canvas'][1],'Region outside canvas: '+key
 assert p['support'].get('perspective_rationale'),'Match support perspective to product'
 anchor=p['support'].get('anchor');assert len(anchor or [])==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in anchor),'Contact anchor required'
 assert 0<=anchor[0]<p['canvas'][0] and 0<=anchor[1]<p['canvas'][1],'Contact anchor outside canvas'
 assert p['materials'].get('strategy') and p['materials'].get('limitations'),'Material treatment and limitations required'
 assert p['composition'].get('mode') and p['composition'].get('reason'),'Product-specific composition required'
 photo=p.get('photography',{})
 for key in ('product_bounds','visual_center','camera_height','depth_of_field','key_light','ambient_light'):assert photo.get(key),'Photography plan missing '+key
 bounds=photo['product_bounds'];assert len(bounds)==4 and 0<=bounds[0]<bounds[2]<=p['canvas'][0] and 0<=bounds[1]<bounds[3]<=p['canvas'][1],'Product bounds outside canvas'
 center=photo['visual_center'];assert len(center)==2 and bounds[0]<=center[0]<=bounds[2] and bounds[1]<=center[1]<=bounds[3],'Visual centre outside planned product'
 assert p['palette'].get('roles') and p['palette'].get('rationale')
 from color_strategy import validate as validate_color
 validate_color(root,p)
 if p['palette'].get('brand_is_design_basis'):assert p['palette'].get('scene_applications'),'Brand needs environmental application'
 for prop in p['props']:
  assert prop.get('relation') and prop.get('role') in (2,3,4),'Prop meaning/hierarchy required'
  assert not prop.get('unsupported_claim'),'Props cannot imply unsupported claims'
 if locate(root,'brief.json').is_file():
  brief=read(locate(root,'brief.json'));product=brief['product'];delivery=brief['delivery']
  assert locate(root,p['source'])==locate(root,product['image']),'Plan source differs from current original product'
  assert locate(root,p['logo'])==locate(root,product['logo']),'Plan logo differs from current original logo'
  assert p['canvas']==[delivery['width'],delivery['height']],'Plan canvas differs from current task'
  available={x['id'] for lang in delivery['languages'] for x in brief['copy'][lang]}
  assert set(p['layout']['feature_groups'][0].get('copy_ids',[]))<=available,'Feature IDs absent from current copy'
 return p

def prepare(root,planfile,work='working/scene-pipeline'):
 root=Path(root).resolve();p=validate(root,read(locate(root,planfile)));folder=locate(root,work);folder.mkdir(parents=True,exist_ok=True)
 refs=[p['source']]+p.get('style_references',[])
 for ref in refs:assert locate(root,ref).is_file(),'Missing generation reference '+ref
 from scene_workflow import colors
 write(folder/'color-analysis.json',{'logo_candidates':colors(locate(root,p['logo']),p.get('logo_color_roi')),'product_candidates':colors(locate(root,p['source']),p.get('product_color_roi')),'logo_sha256':sha(locate(root,p['logo'])),'adopted_strategy':p['palette'],'note':'Actual source samples and selected strategy; candidates are not official standards or visual harmony proof.'})
 prompt=('Product-Anchored Unified Hero Generation. The ORIGINAL PRODUCT PHOTO is the primary identity reference. Generate product, supporting surface, natural light/shadows, props and environment jointly in one photographic space. Do not generate an empty scene for later product pasting.\n'
  +'Canvas: '+str(p['canvas'])+'\nIdentity constraints: '+json.dumps(p['identity_constraints'],ensure_ascii=False)+'\nCamera: '+json.dumps(p['camera'],ensure_ascii=False)+'\nMaterial treatment: '+json.dumps(p['materials'],ensure_ascii=False)+'\nComposition: '+json.dumps(p['composition'],ensure_ascii=False)+'\nSupport: '+json.dumps(p['support'],ensure_ascii=False)+'\nPalette: '+json.dumps(p['palette'],ensure_ascii=False)+'\nProps: '+json.dumps(p['props'],ensure_ascii=False)+'\nInformation regions: '+json.dumps(p['layout'],ensure_ascii=False)+'\nNo marketing typography or standalone brand logo. Preserve original embedded product markings and controls; never use a lookalike product. Jointly create real contact, cast shadow, AO, glass transmission/reflection and natural lighting. If details drift, revise the unified hero instead of passing a plausible substitute. Style references are photographic guidance, not product/fact sources.')
 prompt+='\nShared photography (planned position/scale, camera height, depth, main/ambient light): '+json.dumps(p['photography'],ensure_ascii=False)
 brief_path=locate(root,'brief.json')
 if brief_path.is_file():
  b=read(brief_path);prompt+='\nCurrent audience/goal/visual strategy (facts stay in later precise typography): '+json.dumps({'requirements':b['requirements'],'visual_strategy':b['design']['visual_strategy']},ensure_ascii=False)
 (folder/'generation-plan.txt').write_text(prompt,encoding='utf-8')
 write(folder/'generation-inputs.json',{'method':'product_referenced_joint_generation','prompt':prompt,'referenced_image_paths':[str(locate(root,v)) for v in refs],'transparent_background':False,'note':'Actual agent must call an available image-generation/editing tool with these inputs; this file is not a generated image.'})
 receipt={'mode':'unified_hero','stage':'PREPARED','plan':planfile,'plan_sha256':sha(locate(root,planfile)),'source_sha256':sha(locate(root,p['source'])),'logo_sha256':sha(locate(root,p['logo'])),'reference_inputs':[{'path':v,'sha256':sha(locate(root,v))} for v in refs],'visual_status':'NOT_CHECKED'}
 if brief_path.is_file():receipt.update(brief='brief.json',brief_sha256=sha(brief_path))
 write(folder/'receipt.json',receipt);return receipt

def frozen(root,planfile,work):
 p=validate(root,read(locate(root,planfile)));r=read(locate(root,work)/'receipt.json')
 for k,v in [('plan',planfile),('source',p['source']),('logo',p['logo'])]:assert sha(locate(root,v))==r[k+'_sha256'],k+' changed; prepare again'
 for item in r['reference_inputs']:assert sha(locate(root,item['path']))==item['sha256'],'Reference changed'
 if r.get('brief'):assert sha(locate(root,r['brief']))==r['brief_sha256'],'Task/copy changed; prepare again'
 return p,r

def ingest(root,planfile,generated,submission,work='working/scene-pipeline'):
 p,r=frozen(root,planfile,work);q=read(locate(root,submission))
 assert q.get('method')=='product_referenced_joint_generation' and q.get('tool') and q.get('prompt_path') and q.get('tool_call_evidence'),'Record actual joint generation call'
 assert locate(root,q['prompt_path']).is_file()
 assert q.get('referenced_image_paths',[])==[v['path'] for v in r['reference_inputs']],'Actual original-first reference inputs differ from prepared references'
 assert Image.open(locate(root,generated)).size==tuple(p['canvas']),'Adapt canvas before ingest; never warp product alone'
 r.update(stage='HERO_GENERATED',generated=generated,generated_sha256=sha(locate(root,generated)),submission=submission,submission_sha256=sha(locate(root,submission)),visual_status='NOT_CHECKED')
 r.update(prompt=q['prompt_path'],prompt_sha256=sha(locate(root,q['prompt_path'])))
 write(locate(root,work)/'receipt.json',r);return r

def accept(root,planfile,output,review,work='working/scene-pipeline'):
 p,r=frozen(root,planfile,work);assert r['stage'] in ('HERO_GENERATED','HERO_ACCEPTED')
 assert sha(locate(root,r['generated']))==r['generated_sha256'] and sha(locate(root,r['submission']))==r['submission_sha256'],'Generated input/submission changed'
 assert sha(locate(root,r['prompt']))==r['prompt_sha256'],'Actual generation prompt changed'
 q=read(locate(root,review))
 for k in REVIEWS:
  a=q.get(k,{});assert a.get('status')=='PASS' and a.get('evidence'),'Missing actual identity/space review: '+k
 for item in q.get('comparison_images',[]):assert locate(root,item).is_file(),'Missing comparison image'
 assert q.get('comparison_images'),'Save original/candidate comparison'
 repairs=q.get('detail_repairs',[])
 for repair in repairs:
  assert repair.get('source') and repair.get('region') and repair.get('reason'),'Local precise identity repair must be documented'
  assert locate(root,repair['source'])==locate(root,p['source']),'Local identity repair must use current original source'
  assert not repair.get('whole_product_reoverlay'),'Whole product pasting cannot be presented as unified generation'
 assert Image.open(locate(root,output)).size==tuple(p['canvas'])
 r.update(stage='HERO_ACCEPTED',output=output,output_sha256=sha(locate(root,output)),review=review,review_sha256=sha(locate(root,review)),detail_repairs=repairs,visual_status='REVIEW_RECORDED')
 write(locate(root,work)/'receipt.json',r);return r

def check_record(root,record):
 try:
  p,r=frozen(root,record['plan'],record['work']);assert r['stage']=='HERO_ACCEPTED','Joint hero not generated and reviewed'
  for k in ('generated','submission','prompt','review','output'):assert sha(locate(root,r[k]))==r[k+'_sha256'],k+' hash mismatch'
  q=read(locate(root,r['review']))
  for k in REVIEWS:assert q[k]['status']=='PASS' and q[k]['evidence'],k+' no review'
  return []
 except Exception as e:return ['unified_hero: '+str(e)]
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('command',choices=['prepare','ingest','accept']);a.add_argument('--project',required=True);a.add_argument('--plan',required=True);a.add_argument('--work',default='working/scene-pipeline');a.add_argument('--generated');a.add_argument('--submission');a.add_argument('--out');a.add_argument('--review');x=a.parse_args();r=Path(x.project).resolve()
 v=prepare(r,x.plan,x.work) if x.command=='prepare' else ingest(r,x.plan,x.generated,x.submission,x.work) if x.command=='ingest' else accept(r,x.plan,x.out,x.review,x.work);print(json.dumps(v,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
