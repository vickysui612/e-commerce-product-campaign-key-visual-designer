"""Synthetic behavior checks, not poster generation or human-approval evidence."""
from pathlib import Path
import tempfile, copy, json
from PIL import Image
import preflight as p
from selftest import build_font
import layout_probe
from selftest_scene import fixture as scene_fixture

def run():
    checks=[]
    with tempfile.TemporaryDirectory(prefix='member-v3-check-') as tmp:
        r=Path(tmp);p.init(r)
        build_font(r/'assets/fonts/zh/test.ttf','AB测试')
        build_font(r/'assets/fonts/en/test.ttf','AB')
        fonts=p.read(r/'assets/fonts.json')
        for lang in ('zh','en'): fonts['roles'][lang+'_headline']['primary']='assets/fonts/'+lang+'/test.ttf'
        p.write(r/'assets/fonts.json',fonts)
        for name in ('product','logo'): Image.new('RGB',(20,20),'white').save(r/(name+'.png'))
        b=p.read(r/'brief.json')
        b['delivery'].update(width=100,height=125)
        b['sources']=[{'id':'S1','type':'synthetic','locator':'Fixture only; no real source or person'}]
        b['requirements'].update(purpose='fixture',audience='fixture',goal='fixture',mandatory_copy_ids=['title'])
        b['product'].update(image='product.png',logo='logo.png')
        b['facts']=[{'id':'F1','key':'feature','value':'fixture','claim':'fixture','source_ids':['S1'],'locator':'fixture','classification':'must_show','status':'confirmed'}]
        for lang,text in [('zh','测试'),('en','AB')]:
            b['copy'][lang]=[{'id':'title','text':text,'source_ids':['S1'],'fact_ids':['F1'],'status':'confirmed'}]
        d=b['design'];d.update(directions=[{'id':'A'},{'id':'B'}],selected_id='A',selection_reason='fixture',rejected_reasons=['fixture'],brief_rationale='fixture')
        d['visual_strategy']={key:'fixture' for key in d['visual_strategy']}
        p.write(r/'brief.json',b);p.snapshot(r,'output/working/render-manifest.json')
        m=p.read(r/'output/working/render-manifest.json')
        m['scene_pipeline']=scene_fixture(r)
        for lang in ('zh','en'):
            f='assets/fonts/'+lang+'/test.ttf';s=b['copy'][lang][0]['text']
            m['rendered_text'][lang]=[{'id':'title','text':s}]
            m['text_blocks'][lang]=[{'id':'title','runs':[{'text':s,'font_role':lang+'_headline','font_path':f,'font_sha256':p.sha(r/f),'fallback_reason':''}]}]
            m['fonts_used'].append({'path':f,'usage':lang+'_headline','license':'synthetic fixture'})
            Image.new('RGB',(100,125),'white' if lang=='zh' else 'black').save(r/(lang+'.png'))
            m['outputs'].append({'language':lang,'path':lang+'.png'})
        for gate in m['gates'].values(): gate.update(status='PASS',reviewer='human',evidence='Synthetic test fixture; NOT a real human answer')
        reviewed=[{'language':item['language'],'sha256':p.sha(r/item['path'])} for item in m['outputs']]
        for key in ('T_layout_promotion','C_final'):m['gates'][key]['reviewed_outputs']=reviewed
        for review in m['visual_qa'].values(): review.update(status='PASS',evidence='Synthetic fixture; NOT actual visual QA')
        for subcheck in m['visual_qa']['color_harmony']['checks'].values():subcheck.update(status='PASS',evidence='Synthetic fixture only, not actual visual inspection')
        m['layout_audit'].update(method='manual',evidence='Synthetic fixture only')
        def check(bb=None,mm=None):
            p.write(r/'brief.json',b if bb is None else bb)
            p.write(r/'output/working/render-manifest.json',m if mm is None else mm)
            return p.check(r,'output/working/render-manifest.json')
        assert check()['status']=='PASS'
        checks.append('Valid schema2 synthetic bilingual fixture passes')
        for child in ('logo_color_source','scene_harmony','beyond_text','unified_color_system','brand_scene_style','logo_hidden_consistency'):
            x=copy.deepcopy(m);x['visual_qa']['color_harmony']['checks'][child]['status']='FAIL'
            assert any('Brand Color Harmony QA' in e for e in check(mm=x)['errors'])
        x=copy.deepcopy(m);x['visual_qa']['color_harmony']['checks'].pop('logo_hidden_consistency')
        assert any('logo_hidden_consistency' in e for e in check(mm=x)['errors'])
        checks.append('Parent color PASS cannot override any failed or missing six-part brand harmony review')
        from feature_module import QA_KEYS
        p.write(r/'feature-report.json',{'feature_modules':[{'id':'synthetic group, no actual icon poster'}]})
        x=copy.deepcopy(m);x['layout_audit'].update(report_path='feature-report.json')
        for item in x['visual_qa']['typography_layout']['feature_checks'].values():item.update(status='PASS',evidence='Synthetic fixture only')
        assert check(mm=x)['status']=='PASS'
        for child in QA_KEYS:
            y=copy.deepcopy(x);y['visual_qa']['typography_layout']['feature_checks'][child]['status']='FAIL'
            assert any('Icon + Text QA' in e for e in check(mm=y)['errors'])
        checks.append('Measured feature modules require all actual alignment, metrics, semantics and bilingual subchecks')
        x=copy.deepcopy(m);x['gates']['B_direction']['reviewer']='executor'
        assert any('waiver' in e for e in check(mm=x)['errors'])
        y=copy.deepcopy(b);y['review_policy']['waivers']['B_direction']={'authorized_by':'human','evidence':'Synthetic authorization fixture only'}
        assert check(y,x)['status']=='PASS'
        checks.append('Human review enforced; explicit same-gate waiver accepted')
        x=copy.deepcopy(m);x['gates']['T_layout_promotion']['status']='PENDING'
        assert any('T_layout_promotion' in e for e in check(mm=x)['errors'])
        x=copy.deepcopy(m);x['gates']['T_layout_promotion']['reviewed_outputs']=[]
        assert any('current bilingual output hashes' in e for e in check(mm=x)['errors'])
        checks.append('New human typography/promotion gate and current-image binding enforced')
        for key in ('contact_grounding','typography_layout','headline_motion','promotion_composition','color_harmony','perspective_material','prop_hierarchy','typeface_fit','unified_product_identity','photographic_unity','information_cohesion'):
            for status in (None,'NOT_CHECKED','FAIL','REVISE'):
                x=copy.deepcopy(m)
                if status is None: x['visual_qa'].pop(key)
                else: x['visual_qa'][key]['status']=status
                assert any(key in e for e in check(mm=x)['errors'])
            x=copy.deepcopy(m);x['visual_qa'][key]['evidence']=''
            assert any(key in e for e in check(mm=x)['errors'])
        checks.append('Missing/pending/failed/evidence-free contact, layout, headline-motion and promotion reviews block final approval')
        y=copy.deepcopy(b);y['facts'].append(dict(y['facts'][0],id='F2',value='different'))
        assert any('Conflicting values' in e for e in check(y)['errors'])
        x=copy.deepcopy(m);x['rendered_text']['en'][0]['text']='A'
        assert any('differs' in e for e in check(mm=x)['errors'])
        checks.append('Unresolved fact conflicts and altered rendered copy fail')
        y=copy.deepcopy(b);y['facts'][0]['classification']='forbidden'
        assert any('forbidden fact' in e for e in check(y)['errors'])
        y=copy.deepcopy(b);y['copy']['en'][0]['fact_ids']=[]
        assert any('must_show' in e for e in check(y)['errors'])
        checks.append('Forbidden facts and missing required-fact mapping fail')
        y=copy.deepcopy(b);y['copy']['en'][0]['status']='confirmed_translation'
        assert any('translation' in e or 'translated' in e for e in check(y)['errors'])
        y['translation_authorization']={'en':{'authorized_by':'human','evidence':'Synthetic approval fixture'}}
        assert check(y)['status']=='PASS'
        checks.append('Executor translation requires documented user authorization')
        for lang in ('zh','en'): Image.new('RGB',(100,100),'white').save(r/(lang+'.png'))
        y=copy.deepcopy(b);y['delivery']['height']=100
        assert any('override' in e for e in check(y)['errors'])
        y['exam_override']={'width':100,'height':100,'source_id':'S1','evidence':'Synthetic teacher square requirement'}
        assert check(y)['status']=='PASS'
        checks.append('1:1 delivery requires documented teacher override')
        for lang in ('zh','en'): Image.new('RGB',(100,125),'white').save(r/(lang+'.png'))
        x=copy.deepcopy(m);x['outputs'][1]['path']='zh.png'
        assert any('same file' in e for e in check(mm=x)['errors'])
        original=(r/'zh.png').read_bytes();(r/'zh.png').write_bytes(original[:24])
        assert any('decode' in e for e in check()['errors'])
        (r/'zh.png').write_bytes(original)
        checks.append('Same output path and header-only broken PNGs fail')
        broken=copy.deepcopy(fonts);broken['roles']['zh_headline']['primary']='assets/fonts/en/test.ttf'
        p.write(r/'assets/fonts.json',broken)
        assert any('Missing glyphs' in e for e in check()['errors'])
        broken['roles']['zh_headline']['fallbacks']=['assets/fonts/zh/test.ttf']
        p.write(r/'assets/fonts.json',broken)
        assert any('Fallback' in e for e in check()['errors'])
        x=copy.deepcopy(m);x['text_blocks']['zh'][0]['runs'][0]['fallback_reason']='Primary lacks Chinese glyphs'
        assert check(mm=x)['status']=='PASS'
        p.write(r/'assets/fonts.json',fonts)
        checks.append('Missing glyphs fail; font fallback requires explicit evidence')
        before=(r/'assets/fonts.json').read_bytes();p.init(r)
        assert (r/'assets/fonts.json').read_bytes()==before
        checks.append('init preserves font mappings')
        y=copy.deepcopy(b);y['schema_version']=1
        assert any('Schema 1' in e for e in check(y)['errors'])
        checks.append('Legacy records cannot bypass new final gates')
        probe=layout_probe.fit({'blocks':[{'id':'test','font':str(r/'assets/fonts/en/test.ttf'),'width':1,'height':1,'min_size':24,'max_size':24,'variants':['AB']} ]})
        assert not probe['blocks'][0]['candidates'][0]['fits']
        checks.append('Text-fit measurement reports overflow without rewriting copy')
        p.write(r/'brief.json',b)
        try: p.snapshot(r,'output/working/render-manifest.json')
        except ValueError: pass
        else: raise AssertionError('Snapshot baseline overwritten')
        checks.append('Original asset hash baseline cannot be reset')
    return {'status':'PASS','checks':checks,'scope':'Synthetic software checks only; no actual poster or human review certified.'}

if __name__=='__main__': print(json.dumps(run(),ensure_ascii=False,indent=2))
