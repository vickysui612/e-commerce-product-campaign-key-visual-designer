"""Preserved delivery/default/font safeguards for the schema-2 checker."""
from pathlib import Path
from PIL import Image
import preflight_legacy as legacy

def check(root, brief, manifest):
    errors, warnings = [], []
    delivery=brief.get('delivery', {})
    override=brief.get('delivery_override') or brief.get('exam_override') or {}
    sources={s.get('id') for s in brief.get('sources', [])}
    w,h=delivery.get('width'),delivery.get('height')
    changed=[]
    if type(w)==int and type(h)==int and w*5 != h*4: changed += ['width','height']
    if sorted(delivery.get('languages', [])) != ['en','zh']: changed.append('languages')
    if delivery.get('format','').upper() != 'PNG': changed.append('format')
    for field in changed:
        if override.get(field)!=delivery.get(field) or override.get('source_id') not in sources or not override.get('evidence'):
            errors.append('Default delivery override needs a current source and exact evidence: '+field)
    if override and (override.get('source_id') not in sources or not override.get('evidence')):
        errors.append('Delivery override needs a valid source and evidence.')
    seen=set()
    for out in manifest.get('outputs',[]):
        try:
            p=legacy.resolve(root,out.get('path'))
            if p in seen: errors.append('Language versions cannot point to the same file.')
            seen.add(p)
            with Image.open(p) as im:
                im.load()
                if im.format!='PNG' or im.size!=(w,h): errors.append('Full image decode/specification mismatch: '+str(p))
        except Exception as exc: errors.append('Image decode failed: '+str(exc))

    config=legacy.read_json(root/'assets/fonts.json')
    inventory=legacy.scan(root)
    warnings += ['Unreadable local font: '+f['path'] for f in inventory['errors']]
    roles=config.get('roles',{})
    used_paths=set()
    for item in manifest.get('fonts_used',[]):
        try: used_paths.add(legacy.resolve(root,item.get('path')))
        except Exception as exc: errors.append('Font record invalid: '+str(exc))
    forbidden={f.get('id') for f in brief.get('facts',[]) if f.get('classification')=='forbidden'}
    for lang in delivery.get('languages',[]):
        copy=brief.get('copy',{}).get(lang,[])
        blocks=manifest.get('text_blocks',{}).get(lang,[])
        ids=[b.get('id') for b in blocks]
        if len(ids)!=len(set(ids)) or set(ids)!={c.get('id') for c in copy}:
            errors.append(lang+': actual font-run IDs must match copy exactly once.')
        for c in copy:
            label=lang+':'+str(c.get('id'))
            if forbidden.intersection(c.get('fact_ids',[])): errors.append(label+': forbidden fact mapped into poster copy.')
            if c.get('status')=='confirmed_translation':
                auth=brief.get('translation_authorization',{}).get(lang,{})
                if auth.get('authorized_by')!='human' or not auth.get('evidence'):
                    errors.append(label+': translated copy requires user authorization/confirmation evidence.')
            matching=[b for b in blocks if b.get('id')==c.get('id')]
            if len(matching)!=1: continue
            runs=matching[0].get('runs',[])
            if not runs or ''.join(r.get('text','') for r in runs)!=c.get('text'):
                errors.append(label+': font runs differ from exact copy.')
            for run in runs:
                try:
                    role=roles.get(run.get('font_role'))
                    if not role: raise ValueError('Missing configured font role')
                    actual=legacy.resolve(root,run.get('font_path'))
                    candidates=[role.get('primary')]+role.get('fallbacks',[])
                    general=roles.get('fallback',{})
                    candidates += [general.get('primary')]+general.get('fallbacks',[])
                    candidates=list(dict.fromkeys(p for p in candidates if p))
                    chosen=None; failures=[]
                    for path in candidates:
                        try:
                            detail=legacy.font_info(root,path,run.get('text',''))
                            if detail['missing_characters']: raise ValueError('Missing glyphs: '+''.join(detail['missing_characters']))
                            chosen=legacy.resolve(root,path);break
                        except Exception as exc: failures.append(str(exc))
                    fallback=config.get('system_fallback',{})
                    if chosen is None and fallback.get('enabled') and fallback.get('reason'):
                        for path in fallback.get('paths',[]):
                            try:
                                detail=legacy.font_info(root,path,run.get('text',''))
                                if detail['missing_characters']: raise ValueError('Missing glyphs: '+''.join(detail['missing_characters']))
                                chosen=legacy.resolve(root,path);break
                            except Exception as exc: failures.append(str(exc))
                    if chosen is None: raise ValueError('All fonts failed: '+'; '.join(failures))
                    if actual!=chosen: raise ValueError('Rendered font differs from first valid configured choice')
                    primary=legacy.resolve(root,role['primary']) if role.get('primary') else None
                    if actual!=primary:
                        if not run.get('fallback_reason'): raise ValueError('Fallback used without explicit reason')
                        warnings.append(label+': FONT FALLBACK: '+str(actual))
                    if run.get('font_sha256')!=legacy.digest(actual): raise ValueError('Missing or changed rendered font hash')
                    if actual not in used_paths: raise ValueError('Run font absent from fonts_used')
                except Exception as exc: errors.append(label+': '+str(exc))
    return errors,warnings
