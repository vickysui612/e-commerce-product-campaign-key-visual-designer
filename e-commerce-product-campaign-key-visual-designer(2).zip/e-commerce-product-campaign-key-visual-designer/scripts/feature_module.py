"""Measured, bilingual shared icon/title/body modules; no product-specific glyphs or copy."""
import math,statistics
from PIL import Image,ImageDraw,ImageColor

QA_KEYS=('container_contrast','whole_block_alignment','shared_icon_metrics','semantic_match','title_body_hierarchy','bilingual_balance')

def font_size(layout,size,lang,token):
    style=layout['languages'][lang]['styles'][token];w=size[0]
    if 'size_ratio' in style:return round(style['size_ratio']*w)
    if 'size_px' in style:return style['size_px']
    groups=[g['languages'][lang] for g in layout.get('feature_groups',[]) if token in (g['languages'][lang]['title_token'],g['languages'][lang]['body_token'])]
    assert groups,'Automatic feature font sizing needs a text frame'
    normalized=layout.get('coordinate_space','normalized')=='normalized';frame=min(round(c['text_width']*w) if normalized else c['text_width'] for c in groups);is_title=all(c['title_token']==token for c in groups)
    return round(min(w*(.028 if is_title else .022),frame*(.115 if is_title else .09)))

def luminance(color):
    channels=ImageColor.getrgb(color)[:3]
    values=[v/255/12.92 if v/255<=.04045 else ((v/255+.055)/1.055)**2.4 for v in channels]
    return .2126*values[0]+.7152*values[1]+.0722*values[2]

def contrast(a,b):
    x,y=sorted((luminance(a),luminance(b)));return (y+.05)/(x+.05)

def measure(value,font,width,leading,wrap):
    assert value.strip(),'Feature title and explanation must both come from actual copy'
    lines=wrap(value,font,width);boxes=[font.getbbox(line,anchor='lt') for line in lines]
    step=round(font.size*leading);assert step>=max(max(1,b[3]-b[1]) for b in boxes),'Wrapped text lines overlap; adjust shared leading'
    height=(len(lines)-1)*step+max(1,boxes[-1][3]-boxes[-1][1])
    return {'text':value,'lines':lines,'line_step':step,'height':height,'font':font,'width':width}

def plan_groups(layout,brief,size,load_font,wrap):
    w,h=size;normalized=layout.get('coordinate_space','normalized')=='normalized';languages=brief['delivery']['languages'];plans=[]
    xy=lambda pair:[round(pair[0]*w),round(pair[1]*h)] if normalized else [round(v) for v in pair]
    horizontal=lambda value:round(value*w) if normalized else round(value)
    vertical=lambda value:round(value*h) if normalized else round(value)
    for group in layout.get('feature_groups',[]):
        items=group['items'];assert items and group.get('id'),'Feature group needs ID/items'
        assert len({item['id'] for item in items})==len(items),'Duplicate feature unit ID'
        shape=group.get('container_shape','circle');assert shape in ('circle','rounded_square')
        if shape!='circle':assert group.get('style_exception_reason'),'Alternative container needs brand/style reason'
        background=layout['colors'][group['background_color_role']];assert group.get('color_rationale'),'Record relation to current brand/scene palette'
        requested=group.get('foreground_color_role');foreground=layout['colors'][requested] if requested else max(('white','black'),key=lambda c:contrast(c,background))
        assert contrast(foreground,background)>=3,'Icon/container contrast too low; choose another coordinated color'
        ratio=group.get('diameter_ratio',1.0);assert .85<=ratio<=1.10,'Preferred diameter ratio must be .85–1.10'
        pad=group.get('glyph_padding_ratio',.22);stroke=group.get('glyph_stroke_ratio',.045);gapratio=group.get('icon_text_gap_ratio',.25)
        assert .12<=pad<=.35 and .015<=stroke<=.10 and gapratio>0,'Invalid shared glyph padding/stroke/text gap'
        arrangement=group.get('arrangement','vertical');assert arrangement in ('vertical','horizontal','grid')
        result={'id':group['id'],'container_shape':shape,'background':background,'foreground':foreground,'contrast_ratio':contrast(foreground,background),'rows':{},'glyph_padding_ratio':pad,'glyph_stroke_ratio':stroke,'arrangement':arrangement,'style_exception_reason':group.get('style_exception_reason'),'ratio_exception_reason':group.get('ratio_exception_reason'),'visual_status':'NOT_CHECKED'}
        heights=[]
        for lang in languages:
            conf=group['languages'][lang];styles=layout['languages'][lang]['styles'];tt=conf['title_token'];bt=conf['body_token'];ts,bs=styles[tt],styles[bt]
            assert tt!=bt,'Title/body need distinct semantic tokens'
            source={x['id']:x for x in brief['copy'][lang]}
            for item in items:
                entry=item['copy'][lang];assert entry['copy_id'] in source and source[entry['copy_id']]['status'] in ('confirmed','confirmed_translation')
                assert entry['title']+entry['body']==source[entry['copy_id']]['text'],'Feature split changes locked copy'
                assert item.get('semantic_evidence') and item.get('glyph'),'Glyph must explain confirmed feature'
            # One font per semantic role covers the entire group, avoiding per-item fallback differences.
            tf,ti=load_font(lang,tt,''.join(item['copy'][lang]['title'] for item in items));bf,bi=load_font(lang,bt,''.join(item['copy'][lang]['body'] for item in items))
            assert tf.size>=bf.size,'Feature title must not be weaker by accidental size inversion'
            assert (ti['font_path'],ti.get('variation_axes'),tf.size,ts['color_role'])!=(bi['font_path'],bi.get('variation_axes'),bf.size,bs['color_role']),'Title/body lack hierarchy'
            linegap=round(tf.size*group.get('title_body_gap_ratio',.20));assert linegap>=0
            tw=horizontal(conf['text_width']);assert tw>0
            rows=[]
            for item in items:
                entry=item['copy'][lang];title=measure(entry['title'],tf,tw,ts.get('leading',1.2),wrap);body=measure(entry['body'],bf,tw,bs.get('leading',1.2),wrap);total=title['height']+linegap+body['height'];heights.append(total)
                rows.append({'id':item['id'],'copy_id':entry['copy_id'],'title':title,'body':body,'text_height':total,'title_body_gap':linegap,'title_token':tt,'body_token':bt,'title_color':layout['colors'][ts['color_role']],'body_color':layout['colors'][bs['color_role']],'title_font_record':dict(ti,text=entry['title']),'body_font_record':dict(bi,text=entry['body']),'glyph':item['glyph'],'semantic_evidence':item['semantic_evidence']})
            result['rows'][lang]=rows
        low=.85*max(heights);high=1.10*min(heights);preferred=statistics.median(heights)*ratio
        if low>high:
            assert group.get('ratio_exception_reason'),'Wrapped text heights cannot share a balanced icon: replan language widths/group layout first; no per-item shrinking or icon resizing'
            diameter=round(preferred)
        else:diameter=round(max(low,min(high,preferred)))
        assert diameter>0
        result.update(diameter_px=diameter,icon_text_gap_px=round(diameter*gapratio),bilingual_shared=True,measured_height_range=[min(heights),max(heights)])
        common_slot=max(diameter,max(heights))
        for lang,rows in result['rows'].items():
            conf=group['languages'][lang];x,y=xy(conf['position'])
            if conf.get('group_gap') is None:groupgap=round(common_slot*group.get('feature_group_spacing_ratio',.55))
            else:groupgap=vertical(conf['group_gap']) if arrangement=='vertical' else horizontal(conf['group_gap'])
            assert groupgap>=0
            result.setdefault('feature_group_spacing_px',{})[lang]=groupgap
            horizontal_height=max(diameter,max(r['text_height'] for r in rows))
            base_x,base_y=x,y
            for index,row in enumerate(rows):
                if arrangement=='grid':
                    columns=group.get('grid_columns',2);assert columns>=2
                    x=base_x+(index%columns)*horizontal(group['grid_column_width'])
                    y=base_y+(index//columns)*(common_slot+vertical(group['grid_row_gap']))
                blockheight=common_slot if group.get('synchronize_bilingual_rows',True) else (max(diameter,row['text_height']) if arrangement=='vertical' else horizontal_height)
                text_y=y+(blockheight-row['text_height'])/2;icon_y=y+(blockheight-diameter)/2;tx=x+diameter+result['icon_text_gap_px'];row.update(icon_box=[x,icon_y,x+diameter,icon_y+diameter],text_position=[tx,text_y],body_position=[tx,text_y+row['title']['height']+row['title_body_gap']],diameter_to_text_height=diameter/row['text_height'],module_box=[x,y,tx+max(row['title']['width'],row['body']['width']),y+blockheight],vertical_center_error=abs((icon_y+diameter/2)-(text_y+row['text_height']/2)))
                b=row['module_box'];assert 0<=b[0]<b[2]<=w and 0<=b[1]<b[3]<=h,'Feature group exceeds canvas; adjust width/spacing/layout as a group'
                if arrangement=='grid':assert b[2]<=x+horizontal(group['grid_column_width'])+1,'Feature text exceeds grid column'
                if arrangement=='vertical':y+=blockheight+groupgap
                elif arrangement=='horizontal':x=b[2]+groupgap
        plans.append(result)
    # A feature copy may belong to only one concentrated group.
    for lang in languages:
        ids=[r['copy_id'] for g in plans for r in g['rows'][lang]];assert len(ids)==len(set(ids)),'Feature copy repeated across groups'
    return plans

def glyph_icon(group,glyph):
    diameter=group['diameter_px'];scale=4;d=diameter*scale;im=Image.new('RGBA',(d,d));draw=ImageDraw.Draw(im);fill=group['background']
    if group['container_shape']=='circle':draw.ellipse((1,1,d-2,d-2),fill=fill)
    else:draw.rounded_rectangle((1,1,d-2,d-2),radius=round(d*.20),fill=fill)
    pad=group['glyph_padding_ratio']*d;inner=d-2*pad;stroke=max(1,round(inner*group['glyph_stroke_ratio']));color=group['foreground']
    allpoints=[]
    for primitive in glyph:
        coords=primitive.get('points') or [primitive['box'][:2],primitive['box'][2:]]
        assert all(len(q)==2 and all(isinstance(v,(int,float)) and math.isfinite(v) and 0<=v<=1 for v in q) for q in coords),'Glyph coordinate outside normalized box'
        allpoints.extend(coords)
    xs,ys=zip(*allpoints);xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys);longedge=max(xmax-xmin,ymax-ymin);assert longedge>0,'Empty/degenerate glyph'
    factor=inner/longedge
    point=lambda q:(round(d/2+(q[0]-(xmin+xmax)/2)*factor),round(d/2+(q[1]-(ymin+ymax)/2)*factor))
    for primitive in glyph:
        assert primitive['kind'] in ('line','polyline','ellipse','arc'),'Use consistent editable line primitives'
        coords=primitive.get('points') or [primitive['box'][:2],primitive['box'][2:]]
        assert all(len(q)==2 and all(isinstance(v,(int,float)) and math.isfinite(v) and 0<=v<=1 for v in q) for q in coords),'Glyph coordinate outside normalized inner box'
        if primitive['kind'] in ('line','polyline'):
            pts=[point(q) for q in coords];assert len(pts)>=2;draw.line(pts,fill=color,width=stroke,joint='curve')
            for x,y in (pts[0],pts[-1]):draw.ellipse((x-stroke/2,y-stroke/2,x+stroke/2,y+stroke/2),fill=color)
        else:
            box=(*point(coords[0]),*point(coords[1]))
            if primitive['kind']=='ellipse':draw.ellipse(box,outline=color,width=stroke)
            else:draw.arc(box,primitive['start'],primitive['end'],fill=color,width=stroke)
    return im.resize((diameter,diameter),Image.Resampling.LANCZOS)

def paint(layer,lang,plans):
    for group in plans:
        for row in group['rows'][lang]:
            icon=glyph_icon(group,row['glyph']);layer.alpha_composite(icon,(round(row['icon_box'][0]),round(row['icon_box'][1])))
            for key,pos,color in [('title',row['text_position'],row['title_color']),('body',row['body_position'],row['body_color'])]:
                text=row[key]
                for i,line in enumerate(text['lines']):ImageDraw.Draw(layer).text((round(pos[0]),round(pos[1]+i*text['line_step'])),line,font=text['font'],fill=color,anchor='lt')

def serializable(plans):
    def convert(value):
        if isinstance(value,dict):return {k:convert(v) for k,v in value.items() if k!='font'}
        if isinstance(value,list):return [convert(v) for v in value]
        return value
    return convert(plans)

def qa_errors(record):
    checks=record.get('feature_checks',{});return ['Icon + Text QA: '+key+' requires actual PASS/evidence' for key in QA_KEYS if checks.get(key,{}).get('status')!='PASS' or not checks.get(key,{}).get('evidence')]
