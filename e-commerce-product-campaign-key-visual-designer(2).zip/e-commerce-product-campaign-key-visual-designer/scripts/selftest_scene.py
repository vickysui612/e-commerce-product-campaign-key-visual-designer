"""Observable scene workflow tests; synthetic images are not marketing tests."""
from pathlib import Path
import tempfile,json,copy
from PIL import Image,ImageDraw
import scene_workflow as w

def color_fixture(logo):
    return {'roles':{k:'synthetic neutral/brand role' for k in ('primary','secondary','accent','neutral','background_tone')},'rationale':'Synthetic only','analysis':{k:'Synthetic fixture only' for k in ('logo_colors','product_colors','product_materials','target_audience','scene_mood','marketing_theme')},'brand_is_design_basis':True,'brand_color_source':{'method':'logo_sampled','reference':logo,'selected_colors':['#14328c'],'evidence':'Synthetic source only'},'scene_applications':[{'target':'background','palette_role':'neutral','treatment':'synthetic neutral support','relationship':'synthetic brand/neutral relationship'}]}

def fixture(root):
    root=Path(root);Image.new('RGB',(20,20),(80,120,180)).save(root/'pipeline-product.png');Image.new('L',(20,20),255).save(root/'pipeline-mask.png');Image.new('RGB',(20,20),(20,50,140)).save(root/'pipeline-logo.png')
    p={'render_mode':'layered_fallback','fallback_reason':{'category':'information_display','evidence':'Synthetic software fixture only, not a real design default'},'canvas':[100,125],'source':'pipeline-product.png','mask':'pipeline-mask.png','logo':'pipeline-logo.png','camera':{k:'Synthetic observation only' for k in ('angle','elevation','visible_surfaces','vertical_axis','perspective','base_geometry','lighting_direction','material_properties','evidence','limitations')},'transform':{'scale':1,'translation':[40,40],'rotation_degrees':0},'contact_contour':[[0,19],[19,19]],'support':{'polygon':[[0,50],[99,50],[99,124],[0,124]],'anchor':[50,59],'perspective_rationale':'Synthetic matched plane'},'palette':{'roles':{'accent':'#14328c'},'rationale':'synthetic','brand_is_design_basis':True,'scene_applications':['synthetic backdrop']},'materials':{'strategy':'opaque original pixels','limitations':'synthetic 2D'},'composition':{'mode':'center','reason':'fixture'},'props':[],'shadows':{'contact_width':2,'contact_blur':1,'contact_opacity':.5,'ao_blur':3,'ao_opacity':.2,'cast_vector':[12,6],'reference_height':20,'cast_blur':2,'cast_opacity':.2,'color':[0,0,0]}}
    p['palette']=color_fixture(p['logo']);w.write(root/'scene-plan.json',p);w.prepare(root,'scene-plan.json');Image.new('RGB',(100,125),'white').save(root/'scene.png');q={k:{'status':'PASS','evidence':'Synthetic pixels inspected only'} for k in ('perspective','support','lighting','palette','material_backdrop','props')};w.write(root/'review.json',q);w.accept_scene(root,'scene-plan.json','scene.png','review.json');w.composite(root,'scene-plan.json','grounded.png');return {'plan':'scene-plan.json','work':'working/scene-pipeline'}
def run():
    passed=[]
    with tempfile.TemporaryDirectory() as tmp:
        r=Path(tmp);record=fixture(r);assert not w.check_record(r,record)
        out=Image.open(r/'grounded.png').convert('RGB');assert out.getpixel((45,45))==(80,120,180),'Original opaque RGB changed';assert out.getpixel((50,60))!=(255,255,255),'Contact absent'
        passed.append('Original opaque source RGB preserved; actual thin contact pixels affect the support')
        assert w.check_record(r,{})
        p=w.read(r/'scene-plan.json');bad=copy.deepcopy(p);bad['transform']['perspective_warp']=True
        try:w.validate(r,bad)
        except AssertionError:pass
        else:raise AssertionError('Warp accepted')
        bad=copy.deepcopy(p);bad['palette']['scene_applications']=[]
        try:w.validate(r,bad)
        except AssertionError:pass
        else:raise AssertionError('Text-only brand strategy accepted')
        passed.append('Missing pipeline, pseudo-3D transform and text-only brand strategy rejected')
        before=(r/'scene-plan.json').read_bytes();p['transform']['translation']=[95,110];w.write(r/'scene-plan.json',p)
        try:w.prepare(r,'scene-plan.json')
        except AssertionError:pass
        else:raise AssertionError('Unsupported base accepted')
        (r/'scene-plan.json').write_bytes(before)
        receipt=w.read(r/'working/scene-pipeline/receipt.json');receipt['stage']='PREPARED';w.write(r/'working/scene-pipeline/receipt.json',receipt)
        try:w.composite(r,'scene-plan.json','bad.png')
        except AssertionError:pass
        else:raise AssertionError('Unreviewed scene accepted')
        fixture(r);Image.new('RGB',(100,125),'black').save(r/'scene.png');assert w.check_record(r,record)
        passed.append('Outside support, skipped scene review and changed scene hash rejected')
    return {'status':'PASS','checks':passed,'scope':'Software behavior only; no real glass/camera/aesthetic certification'}
if __name__=='__main__':print(json.dumps(run(),indent=2))
