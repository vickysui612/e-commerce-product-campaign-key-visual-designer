"""Portable font inventory and measured text-fit candidates. fit requires Pillow."""
from pathlib import Path
import argparse
import json
import os

def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def inventory(extra):
    home = Path.home()
    roots = [Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts',
             Path('/System/Library/Fonts'), Path('/Library/Fonts'), home / 'Library/Fonts',
             Path('/usr/share/fonts'), Path('/usr/local/share/fonts'), home / '.local/share/fonts',
             home / '.fonts'] + [Path(p) for p in extra]
    found = set()
    for root in roots:
        if root.is_dir():
            for p in root.rglob('*'):
                if p.is_file() and p.suffix.lower() in ('.ttf', '.otf', '.ttc'):
                    found.add(str(p.resolve()))
    return {'fonts': sorted(found), 'note': 'Discoverability does not establish licensing or glyph coverage.'}

def measure(lines, face, leading=1.15, tracking=0):
    from PIL import Image, ImageDraw
    draw = ImageDraw.Draw(Image.new('RGB', (1, 1)))
    boxes = []
    step = round(face.size * leading)
    for i, line in enumerate(lines):
        if tracking:
            cursor = 0.0
            glyphs = []
            for char in line:
                box = draw.textbbox((cursor, i * step), char, font=face)
                glyphs.append(box)
                cursor += draw.textlength(char, font=face) + tracking
            box = (min(b[0] for b in glyphs), min(b[1] for b in glyphs),
                   max(b[2] for b in glyphs), max(b[3] for b in glyphs)) if glyphs else (0, i*step, 0, i*step)
        else:
            box = draw.textbbox((0, i * step), line, font=face)
        boxes.append(box)
    bbox = (min(b[0] for b in boxes), min(b[1] for b in boxes),
            max(b[2] for b in boxes), max(b[3] for b in boxes))
    return bbox, boxes

def fit(spec):
    from PIL import ImageFont
    result = []
    for block in spec['blocks']:
        lo, hi = block.get('min_size', 24), block.get('max_size', 96)
        if lo < 1 or hi < lo or block['width'] <= 0 or block['height'] <= 0:
            raise ValueError('Invalid size or frame for ' + str(block.get('id')))
        candidates = []
        for value in block['variants']:
            lines = value.split('\n')
            record = {'text': value, 'fits': False}
            for size in range(hi, lo-1, -1):
                face = ImageFont.truetype(block['font'], size)
                bbox, boxes = measure(lines, face, block.get('leading', 1.15), block.get('tracking', 0))
                if bbox[2]-bbox[0] <= block['width'] and bbox[3]-bbox[1] <= block['height']:
                    record.update(fits=True, size=size, bbox=bbox, line_boxes=boxes,
                                  width=bbox[2]-bbox[0], height=bbox[3]-bbox[1])
                    break
            candidates.append(record)
        result.append({'id': block['id'], 'font': block['font'],
                       'frame': [block['width'], block['height']], 'candidates': candidates})
    return {'blocks': result, 'note': 'Measures type only; inspect style, glyphs, collisions and actual rendered image separately.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('fonts')
    p.add_argument('--extra', action='append', default=[])
    p.add_argument('--output', required=True)
    p = sub.add_parser('fit')
    p.add_argument('--spec', required=True)
    p.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        data = inventory(args.extra) if args.command == 'fonts' else fit(json.loads(Path(args.spec).read_text(encoding='utf-8-sig')))
        save(args.output, data)
        print(json.dumps({'status': 'PASS', 'output': args.output}, ensure_ascii=False))
    except ImportError:
        print('fit requires Pillow; use another installed layout tool or document manual measurements.')
        return 2
    except Exception as exc:
        print(json.dumps({'status': 'ERROR', 'error': str(exc)}, ensure_ascii=False))
        return 2
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
